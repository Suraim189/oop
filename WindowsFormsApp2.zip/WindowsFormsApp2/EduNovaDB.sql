CREATE DATABASE EduNovaDBss;
GO
USE EduNovaDBss;
GO

CREATE TABLE Roles (
    RoleId INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE Permissions (
    PermissionId INT IDENTITY(1,1) PRIMARY KEY,
    Code NVARCHAR(100) NOT NULL UNIQUE,
    Name NVARCHAR(100) NOT NULL
);

CREATE TABLE RolePermissions (
    RoleId INT NOT NULL,
    PermissionId INT NOT NULL,
    CONSTRAINT PK_RolePermissions PRIMARY KEY (RoleId, PermissionId),
    CONSTRAINT FK_RolePermissions_Role FOREIGN KEY (RoleId) REFERENCES Roles(RoleId),
    CONSTRAINT FK_RolePermissions_Permission FOREIGN KEY (PermissionId) REFERENCES Permissions(PermissionId)
);

CREATE TABLE Users (
    UserId INT IDENTITY(1,1) PRIMARY KEY,
    Username NVARCHAR(50) NOT NULL UNIQUE,
    DisplayName NVARCHAR(100) NOT NULL,
    PasswordHash NVARCHAR(200) NOT NULL,
    RoleId INT NOT NULL,
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedAt DATETIME NOT NULL DEFAULT GETDATE(),
    CONSTRAINT FK_Users_Role FOREIGN KEY (RoleId) REFERENCES Roles(RoleId)
);

CREATE TABLE AuditLogs (
    AuditId INT IDENTITY(1,1) PRIMARY KEY,
    UserId INT NOT NULL,
    Action NVARCHAR(100) NOT NULL,
    EntityName NVARCHAR(100) NOT NULL,
    EntityId NVARCHAR(50) NULL,
    Details NVARCHAR(1000) NULL,
    Timestamp DATETIME NOT NULL DEFAULT GETDATE(),
    CONSTRAINT FK_AuditLogs_User FOREIGN KEY (UserId) REFERENCES Users(UserId)
);

CREATE TABLE GradeClasses (
    GradeClassId INT IDENTITY(1,1) PRIMARY KEY,
    GradeNumber INT NOT NULL UNIQUE,
    DisplayName NVARCHAR(50) NOT NULL
);

CREATE TABLE Sections (
    SectionId INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(10) NOT NULL UNIQUE
);

CREATE TABLE ClassSections (
    ClassSectionId INT IDENTITY(1,1) PRIMARY KEY,
    GradeClassId INT NOT NULL,
    SectionId INT NOT NULL,
    SessionYear INT NOT NULL,
    IsActive BIT NOT NULL DEFAULT 1,
    CONSTRAINT FK_ClassSections_GradeClass FOREIGN KEY (GradeClassId) REFERENCES GradeClasses(GradeClassId),
    CONSTRAINT FK_ClassSections_Section FOREIGN KEY (SectionId) REFERENCES Sections(SectionId)
);

CREATE TABLE SubjectDomains (
    DomainId INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE Subjects (
    SubjectId INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(100) NOT NULL,
    Code NVARCHAR(20) NOT NULL UNIQUE,
    DomainId INT NOT NULL,
    IsActive BIT NOT NULL DEFAULT 1,
    CONSTRAINT FK_Subjects_Domain FOREIGN KEY (DomainId) REFERENCES SubjectDomains(DomainId)
);

CREATE TABLE Teachers (
    TeacherId INT IDENTITY(1,1) PRIMARY KEY,
    FirstName NVARCHAR(50) NOT NULL,
    LastName NVARCHAR(50) NULL,
    DOB DATE NULL,
    Gender NVARCHAR(10) NULL,
    Phone NVARCHAR(30) NULL,
    Address NVARCHAR(200) NULL,
    EmployeeNo NVARCHAR(30) NOT NULL UNIQUE,
    Qualification NVARCHAR(100) NULL,
    HireDate DATE NULL,
    Salary DECIMAL(18,2) NULL,
    IsActive BIT NOT NULL DEFAULT 1,
    EndDate DATE NULL
);

CREATE TABLE TeacherSubjects (
    TeacherId INT NOT NULL,
    SubjectId INT NOT NULL,
    CONSTRAINT PK_TeacherSubjects PRIMARY KEY (TeacherId, SubjectId),
    CONSTRAINT FK_TeacherSubjects_Teacher FOREIGN KEY (TeacherId) REFERENCES Teachers(TeacherId),
    CONSTRAINT FK_TeacherSubjects_Subject FOREIGN KEY (SubjectId) REFERENCES Subjects(SubjectId)
);

CREATE TABLE TeacherDomains (
    TeacherId INT NOT NULL,
    DomainId INT NOT NULL,
    PriorityLevel INT NOT NULL,
    CONSTRAINT PK_TeacherDomains PRIMARY KEY (TeacherId, DomainId),
    CONSTRAINT FK_TeacherDomains_Teacher FOREIGN KEY (TeacherId) REFERENCES Teachers(TeacherId),
    CONSTRAINT FK_TeacherDomains_Domain FOREIGN KEY (DomainId) REFERENCES SubjectDomains(DomainId)
);

CREATE TABLE Students (
    StudentId INT IDENTITY(1,1) PRIMARY KEY,
    FirstName NVARCHAR(50) NOT NULL,
    LastName NVARCHAR(50) NULL,
    DOB DATE NULL,
    Gender NVARCHAR(10) NULL,
    Phone NVARCHAR(30) NULL,
    Address NVARCHAR(200) NULL,
    AdmissionNo NVARCHAR(30) NOT NULL UNIQUE,
    RollNo INT NULL,
    Age INT NOT NULL,
    IsActive BIT NOT NULL DEFAULT 1,
    CONSTRAINT CK_Students_Age CHECK (Age > 0)
);

CREATE TABLE Guardians (
    GuardianId INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(100) NOT NULL,
    Phone NVARCHAR(30) NULL,
    Relation NVARCHAR(30) NULL
);

CREATE TABLE StudentProfiles (
    ProfileId INT IDENTITY(1,1) PRIMARY KEY,
    StudentId INT NOT NULL UNIQUE,
    EmergencyContact NVARCHAR(100) NULL,
    MedicalInfo NVARCHAR(200) NULL,
    PreviousSchool NVARCHAR(100) NULL,
    CONSTRAINT FK_StudentProfiles_Student FOREIGN KEY (StudentId) REFERENCES Students(StudentId)
);

CREATE TABLE Enrollments (
    EnrollmentId INT IDENTITY(1,1) PRIMARY KEY,
    StudentId INT NOT NULL,
    ClassSectionId INT NOT NULL,
    StartDate DATE NOT NULL,
    EndDate DATE NULL,
    IsActive BIT NOT NULL DEFAULT 1,
    CONSTRAINT FK_Enrollments_Student FOREIGN KEY (StudentId) REFERENCES Students(StudentId),
    CONSTRAINT FK_Enrollments_ClassSection FOREIGN KEY (ClassSectionId) REFERENCES ClassSections(ClassSectionId)
);

CREATE TABLE SchoolScheduleConfigs (
    ConfigId INT IDENTITY(1,1) PRIMARY KEY,
    EffectiveFromDate DATE NOT NULL,
    SchoolStartTime TIME NOT NULL,
    SchoolEndTime TIME NOT NULL,
    LectureMinutes INT NOT NULL,
    BreakMinutes INT NOT NULL,
    BreakAfterPeriodIndex INT NOT NULL,
    IsActive BIT NOT NULL DEFAULT 1
);

CREATE TABLE TimeSlots (
    TimeSlotId INT IDENTITY(1,1) PRIMARY KEY,
    ConfigId INT NOT NULL,
    PeriodIndex INT NOT NULL,
    StartTime TIME NOT NULL,
    EndTime TIME NOT NULL,
    SlotType NVARCHAR(10) NOT NULL,
    CONSTRAINT FK_TimeSlots_Config FOREIGN KEY (ConfigId) REFERENCES SchoolScheduleConfigs(ConfigId)
);

CREATE TABLE TimetableEntries (
    EntryId INT IDENTITY(1,1) PRIMARY KEY,
    ClassSectionId INT NOT NULL,
    DayOfWeek INT NOT NULL,
    TimeSlotId INT NOT NULL,
    SubjectId INT NOT NULL,
    TeacherId INT NOT NULL,
    Room NVARCHAR(50) NULL,
    IsActive BIT NOT NULL DEFAULT 1,
    CONSTRAINT FK_TimetableEntries_ClassSection FOREIGN KEY (ClassSectionId) REFERENCES ClassSections(ClassSectionId),
    CONSTRAINT FK_TimetableEntries_TimeSlot FOREIGN KEY (TimeSlotId) REFERENCES TimeSlots(TimeSlotId),
    CONSTRAINT FK_TimetableEntries_Subject FOREIGN KEY (SubjectId) REFERENCES Subjects(SubjectId),
    CONSTRAINT FK_TimetableEntries_Teacher FOREIGN KEY (TeacherId) REFERENCES Teachers(TeacherId)
);

CREATE TABLE TeacherLeaves (
    LeaveId INT IDENTITY(1,1) PRIMARY KEY,
    TeacherId INT NOT NULL,
    LeaveDate DATE NOT NULL,
    FromTime TIME NULL,
    ToTime TIME NULL,
    Reason NVARCHAR(200) NULL,
    Status NVARCHAR(20) NOT NULL,
    RequestedAt DATETIME NOT NULL DEFAULT GETDATE(),
    ApprovedByUserId INT NULL,
    CONSTRAINT FK_TeacherLeaves_Teacher FOREIGN KEY (TeacherId) REFERENCES Teachers(TeacherId),
    CONSTRAINT FK_TeacherLeaves_ApprovedBy FOREIGN KEY (ApprovedByUserId) REFERENCES Users(UserId)
);

CREATE TABLE SubstitutionAssignments (
    SubId INT IDENTITY(1,1) PRIMARY KEY,
    EntryId INT NOT NULL,
    Date DATE NOT NULL,
    OriginalTeacherId INT NOT NULL,
    SubstituteTeacherId INT NOT NULL,
    Reason NVARCHAR(200) NULL,
    Status NVARCHAR(20) NOT NULL,
    CONSTRAINT FK_SubstitutionAssignments_Entry FOREIGN KEY (EntryId) REFERENCES TimetableEntries(EntryId),
    CONSTRAINT FK_SubstitutionAssignments_OriginalTeacher FOREIGN KEY (OriginalTeacherId) REFERENCES Teachers(TeacherId),
    CONSTRAINT FK_SubstitutionAssignments_SubstituteTeacher FOREIGN KEY (SubstituteTeacherId) REFERENCES Teachers(TeacherId)
);

CREATE TABLE Attendance (
    AttendanceId INT IDENTITY(1,1) PRIMARY KEY,
    StudentId INT NOT NULL,
    Date DATE NOT NULL,
    Status NVARCHAR(20) NOT NULL,
    MarkedByUserId INT NOT NULL,
    CONSTRAINT UQ_Attendance_Student_Date UNIQUE (StudentId, Date),
    CONSTRAINT FK_Attendance_Student FOREIGN KEY (StudentId) REFERENCES Students(StudentId),
    CONSTRAINT FK_Attendance_MarkedBy FOREIGN KEY (MarkedByUserId) REFERENCES Users(UserId)
);

CREATE TABLE ExamTypes (
    ExamTypeId INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE Exams (
    ExamId INT IDENTITY(1,1) PRIMARY KEY,
    ExamTypeId INT NOT NULL,
    ClassSectionId INT NOT NULL,
    SubjectId INT NOT NULL,
    ExamDate DATE NOT NULL,
    TotalMarks DECIMAL(18,2) NOT NULL,
    CONSTRAINT FK_Exams_ExamType FOREIGN KEY (ExamTypeId) REFERENCES ExamTypes(ExamTypeId),
    CONSTRAINT FK_Exams_ClassSection FOREIGN KEY (ClassSectionId) REFERENCES ClassSections(ClassSectionId),
    CONSTRAINT FK_Exams_Subject FOREIGN KEY (SubjectId) REFERENCES Subjects(SubjectId)
);

CREATE TABLE Marks (
    MarkId INT IDENTITY(1,1) PRIMARY KEY,
    ExamId INT NOT NULL,
    StudentId INT NOT NULL,
    ObtainedMarks DECIMAL(18,2) NOT NULL,
    CONSTRAINT UQ_Marks_Exam_Student UNIQUE (ExamId, StudentId),
    CONSTRAINT CK_Marks_Obtained CHECK (ObtainedMarks >= 0),
    CONSTRAINT FK_Marks_Exam FOREIGN KEY (ExamId) REFERENCES Exams(ExamId),
    CONSTRAINT FK_Marks_Student FOREIGN KEY (StudentId) REFERENCES Students(StudentId)
);

CREATE TABLE FeeStructures (
    StructureId INT IDENTITY(1,1) PRIMARY KEY,
    ClassSectionId INT NOT NULL UNIQUE,
    MonthlyFee DECIMAL(18,2) NOT NULL,
    AdmissionFee DECIMAL(18,2) NULL,
    MiscFee DECIMAL(18,2) NULL,
    CONSTRAINT CK_FeeStructures_MonthlyFee CHECK (MonthlyFee >= 0),
    CONSTRAINT FK_FeeStructures_ClassSection FOREIGN KEY (ClassSectionId) REFERENCES ClassSections(ClassSectionId)
);

CREATE TABLE FeeVouchers (
    VoucherId INT IDENTITY(1,1) PRIMARY KEY,
    StudentId INT NOT NULL,
    Month INT NOT NULL,
    Year INT NOT NULL,
    TotalAmount DECIMAL(18,2) NOT NULL,
    DueDate DATE NOT NULL,
    Status NVARCHAR(20) NOT NULL,
    CONSTRAINT FK_FeeVouchers_Student FOREIGN KEY (StudentId) REFERENCES Students(StudentId)
);

CREATE TABLE FeePayments (
    PaymentId INT IDENTITY(1,1) PRIMARY KEY,
    VoucherId INT NOT NULL,
    PaidAmount DECIMAL(18,2) NOT NULL,
    PaidOn DATE NOT NULL,
    Method NVARCHAR(50) NOT NULL,
    ReceivedByUserId INT NOT NULL,
    CONSTRAINT CK_FeePayments_PaidAmount CHECK (PaidAmount > 0),
    CONSTRAINT FK_FeePayments_Voucher FOREIGN KEY (VoucherId) REFERENCES FeeVouchers(VoucherId),
    CONSTRAINT FK_FeePayments_ReceivedBy FOREIGN KEY (ReceivedByUserId) REFERENCES Users(UserId)
);

CREATE TABLE Books (
    BookId INT IDENTITY(1,1) PRIMARY KEY,
    Title NVARCHAR(200) NOT NULL,
    ISBN NVARCHAR(50) NOT NULL UNIQUE,
    Author NVARCHAR(100) NULL,
    Category NVARCHAR(100) NULL,
    IsActive BIT NOT NULL DEFAULT 1
);

CREATE TABLE BookCopies (
    CopyId INT IDENTITY(1,1) PRIMARY KEY,
    BookId INT NOT NULL,
    CopyNo NVARCHAR(50) NOT NULL,
    IsAvailable BIT NOT NULL DEFAULT 1,
    CONSTRAINT FK_BookCopies_Book FOREIGN KEY (BookId) REFERENCES Books(BookId)
);

CREATE TABLE BookIssues (
    IssueId INT IDENTITY(1,1) PRIMARY KEY,
    CopyId INT NOT NULL,
    StudentId INT NOT NULL,
    IssuedOn DATE NOT NULL,
    DueOn DATE NOT NULL,
    ReturnedOn DATE NULL,
    FineAmount DECIMAL(18,2) NOT NULL DEFAULT 0,
    CONSTRAINT FK_BookIssues_Copy FOREIGN KEY (CopyId) REFERENCES BookCopies(CopyId),
    CONSTRAINT FK_BookIssues_Student FOREIGN KEY (StudentId) REFERENCES Students(StudentId)
);

CREATE TABLE LibraryFinePolicies (
    PolicyId INT IDENTITY(1,1) PRIMARY KEY,
    FinePerDay DECIMAL(18,2) NOT NULL
);

CREATE TABLE Notifications (
    NotificationId INT IDENTITY(1,1) PRIMARY KEY,
    ToUserId INT NOT NULL,
    Title NVARCHAR(100) NOT NULL,
    Message NVARCHAR(500) NOT NULL,
    Type NVARCHAR(50) NOT NULL,
    IsRead BIT NOT NULL DEFAULT 0,
    CreatedAt DATETIME NOT NULL DEFAULT GETDATE(),
    CONSTRAINT FK_Notifications_User FOREIGN KEY (ToUserId) REFERENCES Users(UserId)
);

CREATE TABLE NotificationPreferences (
    PrefId INT IDENTITY(1,1) PRIMARY KEY,
    UserId INT NOT NULL UNIQUE,
    EnableInApp BIT NOT NULL DEFAULT 1,
    CONSTRAINT FK_NotificationPreferences_User FOREIGN KEY (UserId) REFERENCES Users(UserId)
);

CREATE INDEX IX_Students_AdmissionNo ON Students(AdmissionNo);
CREATE INDEX IX_Teachers_EmployeeNo ON Teachers(EmployeeNo);
CREATE INDEX IX_TimetableEntries_Teacher_TimeSlot_Day ON TimetableEntries(TeacherId, TimeSlotId, DayOfWeek);
CREATE INDEX IX_FeeVouchers_Student_Month_Year ON FeeVouchers(StudentId, Month, Year);

GO
CREATE VIEW vwStudentSummary AS
SELECT s.StudentId,
       s.FirstName + ' ' + ISNULL(s.LastName,'') AS StudentName,
       e.EnrollmentId,
       cs.ClassSectionId,
       gc.DisplayName AS Grade,
       se.Name AS Section,
       g.Name AS GuardianName,
       g.Phone AS GuardianPhone
FROM Students s
LEFT JOIN Enrollments e ON s.StudentId = e.StudentId AND e.IsActive = 1
LEFT JOIN ClassSections cs ON e.ClassSectionId = cs.ClassSectionId
LEFT JOIN GradeClasses gc ON cs.GradeClassId = gc.GradeClassId
LEFT JOIN Sections se ON cs.SectionId = se.SectionId
LEFT JOIN Guardians g ON 1 = 1;

GO

CREATE VIEW vwFeeStatus AS
SELECT v.VoucherId,
       v.StudentId,
       v.TotalAmount,
       ISNULL(SUM(p.PaidAmount),0) AS PaidAmount,
       (v.TotalAmount - ISNULL(SUM(p.PaidAmount),0)) AS DueAmount
FROM FeeVouchers v
LEFT JOIN FeePayments p ON v.VoucherId = p.VoucherId
GROUP BY v.VoucherId, v.StudentId, v.TotalAmount;

GO

CREATE VIEW vwExamResults AS
SELECT m.MarkId,
       e.ExamId,
       s.StudentId,
       st.Name AS SubjectName,
       et.Name AS ExamType,
       m.ObtainedMarks,
       e.TotalMarks
FROM Marks m
JOIN Exams e ON m.ExamId = e.ExamId
JOIN Students s ON m.StudentId = s.StudentId
JOIN Subjects st ON e.SubjectId = st.SubjectId
JOIN ExamTypes et ON e.ExamTypeId = et.ExamTypeId;

GO

CREATE VIEW vwTeacherScheduleToday AS
SELECT t.TeacherId,
       te.EntryId,
       te.DayOfWeek,
       ts.StartTime,
       ts.EndTime,
       sub.Name AS SubjectName
FROM TimetableEntries te
JOIN Teachers t ON te.TeacherId = t.TeacherId
JOIN TimeSlots ts ON te.TimeSlotId = ts.TimeSlotId
JOIN Subjects sub ON te.SubjectId = sub.SubjectId;

GO

CREATE VIEW vwClassTimetableToday AS
SELECT te.EntryId,
       cs.ClassSectionId,
       te.DayOfWeek,
       ts.StartTime,
       ts.EndTime,
       sub.Name AS SubjectName,
       t.FirstName + ' ' + ISNULL(t.LastName,'') AS TeacherName
FROM TimetableEntries te
JOIN ClassSections cs ON te.ClassSectionId = cs.ClassSectionId
JOIN TimeSlots ts ON te.TimeSlotId = ts.TimeSlotId
JOIN Subjects sub ON te.SubjectId = sub.SubjectId
JOIN Teachers t ON te.TeacherId = t.TeacherId;

GO

CREATE PROCEDURE sp_LoginUser
    @username NVARCHAR(50),
    @password NVARCHAR(200)
AS
BEGIN
    SELECT TOP 1 UserId, Username, DisplayName, RoleId, IsActive
    FROM Users
    WHERE Username = @username AND PasswordHash = @password AND IsActive = 1;
END
GO

CREATE PROCEDURE sp_GetUserPermissions
    @userId INT
AS
BEGIN
    SELECT p.PermissionId, p.Code, p.Name
    FROM Users u
    JOIN RolePermissions rp ON u.RoleId = rp.RoleId
    JOIN Permissions p ON rp.PermissionId = p.PermissionId
    WHERE u.UserId = @userId;
END
GO

CREATE PROCEDURE sp_GetDashboardCounts
AS
BEGIN
    SELECT
        (SELECT COUNT(*) FROM Students) AS StudentsCount,
        (SELECT COUNT(*) FROM Teachers) AS TeachersCount,
        (SELECT COUNT(*) FROM ClassSections) AS ClassesCount,
        (SELECT COUNT(*) FROM Notifications WHERE IsRead = 0) AS NotificationsUnread;
END
GO

CREATE PROCEDURE sp_Student_Insert
    @FirstName NVARCHAR(50),
    @LastName NVARCHAR(50),
    @AdmissionNo NVARCHAR(30),
    @RollNo INT,
    @Age INT
AS
BEGIN
    INSERT INTO Students (FirstName, LastName, AdmissionNo, RollNo, Age, IsActive)
    VALUES (@FirstName, @LastName, @AdmissionNo, @RollNo, @Age, 1);
END
GO

CREATE PROCEDURE sp_Student_Update
    @StudentId INT,
    @FirstName NVARCHAR(50),
    @LastName NVARCHAR(50),
    @AdmissionNo NVARCHAR(30),
    @RollNo INT,
    @Age INT,
    @IsActive BIT
AS
BEGIN
    UPDATE Students
    SET FirstName = @FirstName,
        LastName = @LastName,
        AdmissionNo = @AdmissionNo,
        RollNo = @RollNo,
        Age = @Age,
        IsActive = @IsActive
    WHERE StudentId = @StudentId;
END
GO

CREATE PROCEDURE sp_Student_Delete
    @StudentId INT
AS
BEGIN
    DELETE FROM Students WHERE StudentId = @StudentId;
END
GO

CREATE PROCEDURE sp_Student_Get
    @StudentId INT = NULL
AS
BEGIN
    SELECT * FROM Students WHERE (@StudentId IS NULL OR StudentId = @StudentId);
END
GO

CREATE PROCEDURE sp_Teacher_Insert
    @FirstName NVARCHAR(50),
    @LastName NVARCHAR(50),
    @EmployeeNo NVARCHAR(30)
AS
BEGIN
    INSERT INTO Teachers (FirstName, LastName, EmployeeNo, IsActive)
    VALUES (@FirstName, @LastName, @EmployeeNo, 1);
END
GO

CREATE PROCEDURE sp_Teacher_Update
    @TeacherId INT,
    @FirstName NVARCHAR(50),
    @LastName NVARCHAR(50),
    @EmployeeNo NVARCHAR(30),
    @IsActive BIT
AS
BEGIN
    UPDATE Teachers
    SET FirstName = @FirstName,
        LastName = @LastName,
        EmployeeNo = @EmployeeNo,
        IsActive = @IsActive
    WHERE TeacherId = @TeacherId;
END
GO

CREATE PROCEDURE sp_Teacher_Delete
    @TeacherId INT
AS
BEGIN
    DELETE FROM Teachers WHERE TeacherId = @TeacherId;
END
GO

CREATE PROCEDURE sp_Teacher_Get
    @TeacherId INT = NULL
AS
BEGIN
    SELECT * FROM Teachers WHERE (@TeacherId IS NULL OR TeacherId = @TeacherId);
END
GO

CREATE PROCEDURE sp_SetTeacherActiveStatus
    @TeacherId INT,
    @IsActive BIT
AS
BEGIN
    UPDATE Teachers SET IsActive = @IsActive WHERE TeacherId = @TeacherId;
    IF @IsActive = 0
    BEGIN
        UPDATE TimetableEntries
        SET TeacherId = 0
        WHERE TeacherId = @TeacherId AND IsActive = 1;
    END
END
GO

CREATE PROCEDURE sp_CreateOrUpdateScheduleConfig
    @EffectiveFromDate DATE,
    @SchoolStartTime TIME,
    @SchoolEndTime TIME,
    @LectureMinutes INT,
    @BreakMinutes INT,
    @BreakAfterPeriodIndex INT
AS
BEGIN
    UPDATE SchoolScheduleConfigs SET IsActive = 0 WHERE IsActive = 1;
    INSERT INTO SchoolScheduleConfigs (EffectiveFromDate, SchoolStartTime, SchoolEndTime, LectureMinutes, BreakMinutes, BreakAfterPeriodIndex, IsActive)
    VALUES (@EffectiveFromDate, @SchoolStartTime, @SchoolEndTime, @LectureMinutes, @BreakMinutes, @BreakAfterPeriodIndex, 1);
END
GO

CREATE PROCEDURE sp_GenerateTimeSlotsFromConfig
    @ConfigId INT
AS
BEGIN
    DECLARE @currentTime TIME = (SELECT SchoolStartTime FROM SchoolScheduleConfigs WHERE ConfigId = @ConfigId);
    DECLARE @endTime TIME = (SELECT SchoolEndTime FROM SchoolScheduleConfigs WHERE ConfigId = @ConfigId);
    DECLARE @lectureMinutes INT = (SELECT LectureMinutes FROM SchoolScheduleConfigs WHERE ConfigId = @ConfigId);
    DECLARE @breakMinutes INT = (SELECT BreakMinutes FROM SchoolScheduleConfigs WHERE ConfigId = @ConfigId);
    DECLARE @breakAfter INT = (SELECT BreakAfterPeriodIndex FROM SchoolScheduleConfigs WHERE ConfigId = @ConfigId);
    DECLARE @periodIndex INT = 1;

    WHILE @currentTime < @endTime
    BEGIN
        DECLARE @slotType NVARCHAR(10) = 'Lecture';
        DECLARE @slotMinutes INT = @lectureMinutes;

        IF @periodIndex = @breakAfter + 1
        BEGIN
            SET @slotType = 'Break';
            SET @slotMinutes = @breakMinutes;
        END

        INSERT INTO TimeSlots (ConfigId, PeriodIndex, StartTime, EndTime, SlotType)
        VALUES (@ConfigId, @periodIndex, @currentTime, DATEADD(MINUTE, @slotMinutes, @currentTime), @slotType);

        SET @currentTime = DATEADD(MINUTE, @slotMinutes, @currentTime);
        SET @periodIndex = @periodIndex + 1;
    END
END
GO

CREATE PROCEDURE sp_RegenerateTimetableTimesByPeriodIndex
    @ConfigId INT
AS
BEGIN
    UPDATE ts
    SET ts.StartTime = tss.StartTime,
        ts.EndTime = tss.EndTime
    FROM TimeSlots ts
    JOIN TimeSlots tss ON ts.PeriodIndex = tss.PeriodIndex
    WHERE ts.ConfigId = @ConfigId AND tss.ConfigId = @ConfigId;
END
GO

CREATE PROCEDURE sp_TimetableEntry_CRUD
    @Action NVARCHAR(10),
    @EntryId INT = NULL,
    @ClassSectionId INT = NULL,
    @DayOfWeek INT = NULL,
    @TimeSlotId INT = NULL,
    @SubjectId INT = NULL,
    @TeacherId INT = NULL,
    @Room NVARCHAR(50) = NULL
AS
BEGIN
    IF @Action = 'INSERT'
    BEGIN
        IF NOT EXISTS (
            SELECT 1 FROM TimetableEntries
            WHERE TeacherId = @TeacherId AND TimeSlotId = @TimeSlotId AND DayOfWeek = @DayOfWeek AND IsActive = 1
        )
        BEGIN
            INSERT INTO TimetableEntries (ClassSectionId, DayOfWeek, TimeSlotId, SubjectId, TeacherId, Room, IsActive)
            VALUES (@ClassSectionId, @DayOfWeek, @TimeSlotId, @SubjectId, @TeacherId, @Room, 1);
        END
    END
    ELSE IF @Action = 'UPDATE'
    BEGIN
        UPDATE TimetableEntries
        SET ClassSectionId = @ClassSectionId,
            DayOfWeek = @DayOfWeek,
            TimeSlotId = @TimeSlotId,
            SubjectId = @SubjectId,
            TeacherId = @TeacherId,
            Room = @Room
        WHERE EntryId = @EntryId;
    END
    ELSE IF @Action = 'DELETE'
    BEGIN
        DELETE FROM TimetableEntries WHERE EntryId = @EntryId;
    END
END
GO

CREATE PROCEDURE sp_RequestTeacherLeave
    @TeacherId INT,
    @LeaveDate DATE,
    @Reason NVARCHAR(200)
AS
BEGIN
    INSERT INTO TeacherLeaves (TeacherId, LeaveDate, Reason, Status, RequestedAt)
    VALUES (@TeacherId, @LeaveDate, @Reason, 'Pending', GETDATE());

    SELECT te.EntryId
    FROM TimetableEntries te
    WHERE te.TeacherId = @TeacherId AND te.IsActive = 1;
END
GO

CREATE PROCEDURE sp_FindSubstituteTeacher
    @SubjectId INT,
    @DomainId INT,
    @TimeSlotId INT,
    @DayOfWeek INT
AS
BEGIN
    SELECT TOP 1 t.TeacherId
    FROM Teachers t
    LEFT JOIN TeacherSubjects ts ON t.TeacherId = ts.TeacherId AND ts.SubjectId = @SubjectId
    LEFT JOIN TeacherDomains td ON t.TeacherId = td.TeacherId AND td.DomainId = @DomainId
    WHERE t.IsActive = 1
      AND NOT EXISTS (
            SELECT 1 FROM TimetableEntries te
            WHERE te.TeacherId = t.TeacherId AND te.TimeSlotId = @TimeSlotId AND te.DayOfWeek = @DayOfWeek AND te.IsActive = 1
      )
    ORDER BY CASE WHEN ts.SubjectId IS NOT NULL THEN 1 WHEN td.DomainId IS NOT NULL THEN 2 ELSE 3 END;
END
GO

CREATE PROCEDURE sp_AssignSubstitution
    @EntryId INT,
    @Date DATE,
    @OriginalTeacherId INT,
    @SubstituteTeacherId INT,
    @Reason NVARCHAR(200)
AS
BEGIN
    INSERT INTO SubstitutionAssignments (EntryId, Date, OriginalTeacherId, SubstituteTeacherId, Reason, Status)
    VALUES (@EntryId, @Date, @OriginalTeacherId, @SubstituteTeacherId, @Reason, 'Assigned');
END
GO

CREATE PROCEDURE sp_ReplaceTeacherWizard
    @OldTeacherId INT,
    @NewTeacherId INT
AS
BEGIN
    UPDATE te
    SET TeacherId = @NewTeacherId
    FROM TimetableEntries te
    JOIN TeacherSubjects ts ON ts.TeacherId = @NewTeacherId AND ts.SubjectId = te.SubjectId
    WHERE te.TeacherId = @OldTeacherId AND te.IsActive = 1;
END
GO

CREATE PROCEDURE sp_SaveAttendance
    @StudentId INT,
    @Date DATE,
    @Status NVARCHAR(20),
    @MarkedByUserId INT
AS
BEGIN
    IF NOT EXISTS (SELECT 1 FROM Attendance WHERE StudentId = @StudentId AND Date = @Date)
    BEGIN
        INSERT INTO Attendance (StudentId, Date, Status, MarkedByUserId)
        VALUES (@StudentId, @Date, @Status, @MarkedByUserId);
    END
END
GO

CREATE PROCEDURE sp_CreateExam
    @ExamTypeId INT,
    @ClassSectionId INT,
    @SubjectId INT,
    @ExamDate DATE,
    @TotalMarks DECIMAL(18,2)
AS
BEGIN
    INSERT INTO Exams (ExamTypeId, ClassSectionId, SubjectId, ExamDate, TotalMarks)
    VALUES (@ExamTypeId, @ClassSectionId, @SubjectId, @ExamDate, @TotalMarks);
END
GO

CREATE PROCEDURE sp_SaveMarks
    @ExamId INT,
    @StudentId INT,
    @ObtainedMarks DECIMAL(18,2)
AS
BEGIN
    DECLARE @TotalMarks DECIMAL(18,2) = (SELECT TotalMarks FROM Exams WHERE ExamId = @ExamId);
    IF @ObtainedMarks <= @TotalMarks
    BEGIN
        INSERT INTO Marks (ExamId, StudentId, ObtainedMarks)
        VALUES (@ExamId, @StudentId, @ObtainedMarks);
    END
END
GO

CREATE PROCEDURE sp_GetExamResultReport
AS
BEGIN
    SELECT * FROM vwExamResults;
END
GO

CREATE PROCEDURE sp_GenerateFeeVouchers
    @Month INT,
    @Year INT
AS
BEGIN
    INSERT INTO FeeVouchers (StudentId, Month, Year, TotalAmount, DueDate, Status)
    SELECT s.StudentId, @Month, @Year, fs.MonthlyFee, DATEFROMPARTS(@Year, @Month, 10), 'Unpaid'
    FROM Students s
    JOIN Enrollments e ON s.StudentId = e.StudentId AND e.IsActive = 1
    JOIN FeeStructures fs ON e.ClassSectionId = fs.ClassSectionId
    WHERE s.IsActive = 1;
END
GO

CREATE PROCEDURE sp_PayFeeVoucher
    @VoucherId INT,
    @PaidAmount DECIMAL(18,2),
    @PaidOn DATE,
    @Method NVARCHAR(50),
    @ReceivedByUserId INT
AS
BEGIN
    INSERT INTO FeePayments (VoucherId, PaidAmount, PaidOn, Method, ReceivedByUserId)
    VALUES (@VoucherId, @PaidAmount, @PaidOn, @Method, @ReceivedByUserId);
END
GO

CREATE PROCEDURE sp_GetFeeDueStudents
AS
BEGIN
    SELECT v.StudentId, v.VoucherId, v.TotalAmount,
           ISNULL((SELECT SUM(PaidAmount) FROM FeePayments p WHERE p.VoucherId = v.VoucherId),0) AS PaidAmount
    FROM FeeVouchers v
    WHERE v.TotalAmount - ISNULL((SELECT SUM(PaidAmount) FROM FeePayments p WHERE p.VoucherId = v.VoucherId),0) > 0;
END
GO

CREATE PROCEDURE sp_Library_IssueBook
    @CopyId INT,
    @StudentId INT,
    @IssuedOn DATE,
    @DueOn DATE
AS
BEGIN
    INSERT INTO BookIssues (CopyId, StudentId, IssuedOn, DueOn, FineAmount)
    VALUES (@CopyId, @StudentId, @IssuedOn, @DueOn, 0);
    UPDATE BookCopies SET IsAvailable = 0 WHERE CopyId = @CopyId;
END
GO

CREATE PROCEDURE sp_Library_ReturnBook
    @IssueId INT,
    @ReturnedOn DATE,
    @FineAmount DECIMAL(18,2)
AS
BEGIN
    UPDATE BookIssues
    SET ReturnedOn = @ReturnedOn, FineAmount = @FineAmount
    WHERE IssueId = @IssueId;

    UPDATE BookCopies
    SET IsAvailable = 1
    WHERE CopyId = (SELECT CopyId FROM BookIssues WHERE IssueId = @IssueId);
END
GO

CREATE PROCEDURE sp_CreateNotification
    @ToUserId INT,
    @Title NVARCHAR(100),
    @Message NVARCHAR(500),
    @Type NVARCHAR(50)
AS
BEGIN
    INSERT INTO Notifications (ToUserId, Title, Message, Type, IsRead)
    VALUES (@ToUserId, @Title, @Message, @Type, 0);
END
GO

CREATE PROCEDURE sp_GetUnreadNotifications
    @ToUserId INT
AS
BEGIN
    SELECT * FROM Notifications WHERE ToUserId = @ToUserId AND IsRead = 0;
END
GO

INSERT INTO Roles (Name) VALUES ('Admin'), ('Staff'), ('Teacher');
INSERT INTO Permissions (Code, Name) VALUES
('Dashboard.View','View Dashboard'),
('Students.Manage','Manage Students'),
('Teachers.Manage','Manage Teachers'),
('Timetable.Manage','Manage Timetable');
INSERT INTO RolePermissions (RoleId, PermissionId)
SELECT 1, PermissionId FROM Permissions;

INSERT INTO Users (Username, DisplayName, PasswordHash, RoleId, IsActive)
VALUES
('Suraim','Suraim','Admin123',1,1),
('Umair','Umair','Admin123',1,1),
('Mudabber','Mudabber','Admin123',1,1),
('Izzan','Izzan','Admin123',1,1);

DECLARE @i INT = 1;
WHILE @i <= 10
BEGIN
    INSERT INTO GradeClasses (GradeNumber, DisplayName) VALUES (@i, CONCAT('Grade ', @i));
    SET @i = @i + 1;
END
INSERT INTO Sections (Name) VALUES ('A'), ('B');

INSERT INTO ClassSections (GradeClassId, SectionId, SessionYear, IsActive)
SELECT gc.GradeClassId, s.SectionId, YEAR(GETDATE()), 1
FROM GradeClasses gc
CROSS JOIN Sections s;

INSERT INTO SubjectDomains (Name) VALUES ('Science'), ('Arts'), ('Languages');
INSERT INTO Subjects (Name, Code, DomainId, IsActive) VALUES
('Mathematics','MATH',1,1),
('Physics','PHY',1,1),
('Chemistry','CHEM',1,1),
('History','HIST',2,1),
('English','ENG',3,1);

INSERT INTO Teachers (FirstName, LastName, EmployeeNo, Qualification, IsActive)
VALUES
('Ali','Khan','T001','MSc',1),
('Sara','Raza','T002','MA',1),
('Hassan','Iqbal','T003','MEd',1),
('Ayesha','Noor','T004','MSc',1),
('Bilal','Ahmed','T005','MA',1),
('Nida','Zain','T006','MSc',1);

INSERT INTO TeacherSubjects (TeacherId, SubjectId)
VALUES (1,1),(2,4),(3,2),(4,3),(5,5),(6,1);

INSERT INTO TeacherDomains (TeacherId, DomainId, PriorityLevel)
VALUES (1,1,1),(2,2,1),(3,1,2),(4,1,1),(5,3,1),(6,1,2);

INSERT INTO Students (FirstName, LastName, AdmissionNo, RollNo, Age, IsActive)
VALUES
('Hammad','Ali','S001',1,12,1),
('Zara','Noor','S002',2,13,1),
('Usman','Khan','S003',3,12,1),
('Areeba','Iqbal','S004',4,11,1),
('Saad','Ahmed','S005',5,12,1),
('Laiba','Zain','S006',6,13,1),
('Fahad','Raza','S007',7,11,1),
('Maryam','Noor','S008',8,12,1),
('Omar','Hussain','S009',9,13,1),
('Sana','Ali','S010',10,12,1),
('Umer','Khan','S011',11,12,1),
('Hiba','Iqbal','S012',12,13,1),
('Azan','Ahmed','S013',13,11,1),
('Rida','Zain','S014',14,12,1),
('Amin','Raza','S015',15,13,1);

INSERT INTO Guardians (Name, Phone, Relation)
VALUES ('Guardian1','0300-0000001','Father'),('Guardian2','0300-0000002','Mother');

INSERT INTO StudentProfiles (StudentId, EmergencyContact)
VALUES (1,'0300-0000001'),(2,'0300-0000002');

INSERT INTO Enrollments (StudentId, ClassSectionId, StartDate, IsActive)
SELECT TOP 15 s.StudentId, cs.ClassSectionId, GETDATE(), 1
FROM Students s
CROSS JOIN ClassSections cs;

INSERT INTO SchoolScheduleConfigs (EffectiveFromDate, SchoolStartTime, SchoolEndTime, LectureMinutes, BreakMinutes, BreakAfterPeriodIndex, IsActive)
VALUES (CAST(GETDATE() AS DATE), '08:00', '13:30', 40, 15, 3, 1);

DECLARE @ConfigId INT = SCOPE_IDENTITY();
EXEC sp_GenerateTimeSlotsFromConfig @ConfigId;

INSERT INTO FeeStructures (ClassSectionId, MonthlyFee, AdmissionFee, MiscFee)
SELECT TOP 1 ClassSectionId, 2000, 5000, 200 FROM ClassSections;

INSERT INTO FeeVouchers (StudentId, Month, Year, TotalAmount, DueDate, Status)
SELECT TOP 5 StudentId, MONTH(GETDATE()), YEAR(GETDATE()), 2000, DATEADD(DAY,10,GETDATE()), 'Unpaid'
FROM Students;

INSERT INTO FeePayments (VoucherId, PaidAmount, PaidOn, Method, ReceivedByUserId)
SELECT TOP 2 VoucherId, 1000, GETDATE(), 'Cash', 1 FROM FeeVouchers;

INSERT INTO ExamTypes (Name) VALUES ('Monthly'), ('HalfBook'), ('FullBook');

INSERT INTO Exams (ExamTypeId, ClassSectionId, SubjectId, ExamDate, TotalMarks)
SELECT TOP 1 ExamTypeId, ClassSectionId, SubjectId, GETDATE(), 100
FROM ExamTypes, ClassSections, Subjects;

INSERT INTO Marks (ExamId, StudentId, ObtainedMarks)
SELECT TOP 5 e.ExamId, s.StudentId, 80
FROM Exams e
JOIN Students s ON 1 = 1;

INSERT INTO Books (Title, ISBN, Author, Category, IsActive)
VALUES ('C# Fundamentals','ISBN-001','Author A','Programming',1);

INSERT INTO BookCopies (BookId, CopyNo, IsAvailable)
VALUES (1,'COPY-001',1);

INSERT INTO BookIssues (CopyId, StudentId, IssuedOn, DueOn, FineAmount)
VALUES (1,1,GETDATE(),DATEADD(DAY,7,GETDATE()),0);

INSERT INTO Notifications (ToUserId, Title, Message, Type, IsRead)
VALUES (1,'Welcome','Welcome to EduNova','General',0);

