using System;
using EduNova.Domain.Enums;

namespace EduNova.Domain.Entities
{
    public class TimeSlot : BaseEntity
    {
        public int ConfigId { get; set; }
        public int PeriodIndex { get; set; }
        public TimeSpan StartTime { get; set; }
        public TimeSpan EndTime { get; set; }
        public SlotType SlotType { get; set; }
        public SchoolScheduleConfig Config { get; set; }
    }
}
