namespace EduNova.Domain.Entities
{
    public class ExamType : BaseEntity
    {
        public string Name { get; set; }
    }
}
