namespace EduNova.Domain.Entities
{
    public class SubjectDomain : BaseEntity
    {
        public string Name { get; set; }
    }
}
