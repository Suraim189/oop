using System;

namespace EduNova.Domain.Entities
{
    public class Enrollment : BaseEntity
    {
        public int StudentId { get; set; }
        public int ClassSectionId { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public bool IsActive { get; set; }
        public Student Student { get; set; }
        public ClassSection ClassSection { get; set; }
    }
}
