namespace EduNova.Domain.Entities
{
    public class Subject : BaseEntity
    {
        public int DomainId { get; set; }
        public string Name { get; set; }
        public string Code { get; set; }
        public bool IsActive { get; set; }
        public SubjectDomain Domain { get; set; }
    }
}
