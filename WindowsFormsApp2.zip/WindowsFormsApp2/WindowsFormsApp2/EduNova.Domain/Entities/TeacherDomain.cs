namespace EduNova.Domain.Entities
{
    public class TeacherDomain : BaseEntity
    {
        public int TeacherId { get; set; }
        public int DomainId { get; set; }
        public int PriorityLevel { get; set; }
        public Teacher Teacher { get; set; }
        public SubjectDomain Domain { get; set; }
    }
}
