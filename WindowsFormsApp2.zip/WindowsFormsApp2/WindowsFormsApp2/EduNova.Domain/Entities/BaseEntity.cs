using System;
using EduNova.Domain.Interfaces;

namespace EduNova.Domain.Entities
{
    public class BaseEntity : IAuditable
    {
        public int Id { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
    }
}
