namespace EduNova.Domain.Entities
{
    public class LibraryFinePolicy : BaseEntity
    {
        public decimal FinePerDay { get; set; }
    }
}
