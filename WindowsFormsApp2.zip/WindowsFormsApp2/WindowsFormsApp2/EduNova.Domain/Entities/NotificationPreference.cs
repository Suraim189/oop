namespace EduNova.Domain.Entities
{
    public class NotificationPreference : BaseEntity
    {
        public int UserId { get; set; }
        public bool EnableInApp { get; set; }
        public User User { get; set; }
    }
}
