namespace EduNova.Domain.Entities
{
    public class Mark : BaseEntity
    {
        public int ExamId { get; set; }
        public int StudentId { get; set; }
        public decimal ObtainedMarks { get; set; }
        public Exam Exam { get; set; }
        public Student Student { get; set; }
    }
}
