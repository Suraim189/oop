using System;

namespace EduNova.Domain.Entities
{
    public class Exam : BaseEntity
    {
        public int ExamTypeId { get; set; }
        public int ClassSectionId { get; set; }
        public int SubjectId { get; set; }
        public DateTime ExamDate { get; set; }
        public decimal TotalMarks { get; set; }
        public ExamType ExamType { get; set; }
        public ClassSection ClassSection { get; set; }
        public Subject Subject { get; set; }
    }
}
