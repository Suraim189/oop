using System;

namespace EduNova.Domain.Entities
{
    public class FeePayment : BaseEntity
    {
        public int VoucherId { get; set; }
        public decimal PaidAmount { get; set; }
        public DateTime PaidOn { get; set; }
        public string Method { get; set; }
        public int ReceivedByUserId { get; set; }
        public FeeVoucher Voucher { get; set; }
        public User ReceivedByUser { get; set; }
    }
}
