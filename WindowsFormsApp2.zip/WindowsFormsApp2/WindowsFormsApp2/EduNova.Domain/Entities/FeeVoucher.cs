using System;
using System.Collections.Generic;
using EduNova.Domain.Enums;
using EduNova.Domain.Interfaces;

namespace EduNova.Domain.Entities
{
    public class FeeVoucher : BaseEntity, IValidatable
    {
        public int StudentId { get; set; }
        public int Month { get; set; }
        public int Year { get; set; }
        public decimal TotalAmount { get; set; }
        public DateTime DueDate { get; set; }
        public PaymentStatus Status { get; set; }
        public Student Student { get; set; }

        public List<string> Validate()
        {
            var errors = new List<string>();

            if (StudentId <= 0)
            {
                errors.Add("Student is required.");
            }

            if (TotalAmount <= 0)
            {
                errors.Add("Total amount must be greater than zero.");
            }

            return errors;
        }
    }
}
