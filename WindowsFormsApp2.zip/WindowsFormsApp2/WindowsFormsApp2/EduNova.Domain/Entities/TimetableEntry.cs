using System.Collections.Generic;
using EduNova.Domain.Interfaces;

namespace EduNova.Domain.Entities
{
    public class TimetableEntry : BaseEntity, IValidatable
    {
        public int ClassSectionId { get; set; }
        public int TimeSlotId { get; set; }
        public int SubjectId { get; set; }
        public int TeacherId { get; set; }
        public int DayOfWeek { get; set; }
        public string Room { get; set; }
        public bool IsActive { get; set; }
        public ClassSection ClassSection { get; set; }
        public TimeSlot TimeSlot { get; set; }
        public Subject Subject { get; set; }
        public Teacher Teacher { get; set; }

        public List<string> Validate()
        {
            var errors = new List<string>();

            if (TeacherId <= 0)
            {
                errors.Add("Teacher is required.");
            }
            else if (Teacher != null && !Teacher.IsActive)
            {
                errors.Add("Inactive teacher cannot be assigned.");
            }

            if (SubjectId <= 0)
            {
                errors.Add("Subject is required.");
            }

            if (ClassSectionId <= 0)
            {
                errors.Add("Class section is required.");
            }

            if (TimeSlotId <= 0)
            {
                errors.Add("Time slot is required.");
            }

            return errors;
        }
    }
}
