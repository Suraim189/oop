using System;
using EduNova.Domain.Enums;

namespace EduNova.Domain.Entities
{
    public class TeacherLeave : BaseEntity
    {
        public int TeacherId { get; set; }
        public DateTime LeaveDate { get; set; }
        public TimeSpan? FromTime { get; set; }
        public TimeSpan? ToTime { get; set; }
        public string Reason { get; set; }
        public LeaveStatus Status { get; set; }
        public DateTime RequestedAt { get; set; }
        public int? ApprovedByUserId { get; set; }
        public Teacher Teacher { get; set; }
        public User ApprovedByUser { get; set; }
    }
}
