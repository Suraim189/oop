using System;

namespace EduNova.Domain.Entities
{
    public class BookIssue : BaseEntity
    {
        public int CopyId { get; set; }
        public int StudentId { get; set; }
        public DateTime IssuedOn { get; set; }
        public DateTime DueOn { get; set; }
        public DateTime? ReturnedOn { get; set; }
        public decimal FineAmount { get; set; }
        public BookCopy Copy { get; set; }
        public Student Student { get; set; }
    }
}
