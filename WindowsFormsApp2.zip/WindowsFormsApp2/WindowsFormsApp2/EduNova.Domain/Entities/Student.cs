using System.Collections.Generic;
using EduNova.Domain.Interfaces;

namespace EduNova.Domain.Entities
{
    public class Student : Person, IValidatable
    {
        public string AdmissionNo { get; set; }
        public int RollNo { get; set; }
        public int Age { get; set; }
        public bool IsActive { get; set; }
        public StudentProfile Profile { get; set; }
        public List<Guardian> Guardians { get; set; }
        public List<Enrollment> Enrollments { get; set; }

        public List<string> Validate()
        {
            var errors = new List<string>();

            if (string.IsNullOrWhiteSpace(FirstName) && string.IsNullOrWhiteSpace(LastName))
            {
                errors.Add("Student name is required.");
            }

            if (Age <= 0)
            {
                errors.Add("Student age is required.");
            }

            if (Enrollments == null || Enrollments.Count == 0)
            {
                errors.Add("Student class section enrollment is required.");
            }

            if (!IsActive && Enrollments != null && Enrollments.Count > 0)
            {
                errors.Add("Inactive students cannot be enrolled.");
            }

            return errors;
        }
    }
}
