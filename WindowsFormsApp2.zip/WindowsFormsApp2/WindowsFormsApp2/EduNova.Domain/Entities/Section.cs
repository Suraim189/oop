namespace EduNova.Domain.Entities
{
    public class Section : BaseEntity
    {
        public string Name { get; set; }
    }
}
