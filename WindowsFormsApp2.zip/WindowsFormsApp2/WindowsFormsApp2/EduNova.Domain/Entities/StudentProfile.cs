namespace EduNova.Domain.Entities
{
    public class StudentProfile : BaseEntity
    {
        public int StudentId { get; set; }
        public string EmergencyContact { get; set; }
        public string MedicalInfo { get; set; }
        public string PreviousSchool { get; set; }
        public Student Student { get; set; }
    }
}
