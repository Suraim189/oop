using System.Collections.Generic;
using EduNova.Domain.Interfaces;

namespace EduNova.Domain.Entities
{
    public class Teacher : Person, IValidatable
    {
        public string EmployeeNo { get; set; }
        public string Qualification { get; set; }
        public decimal Salary { get; set; }
        public bool IsActive { get; set; }
        public List<TeacherSubject> Subjects { get; set; }
        public List<TeacherDomain> Domains { get; set; }

        public List<string> Validate()
        {
            var errors = new List<string>();

            if (string.IsNullOrWhiteSpace(FirstName) && string.IsNullOrWhiteSpace(LastName))
            {
                errors.Add("Teacher name is required.");
            }

            if (string.IsNullOrWhiteSpace(EmployeeNo))
            {
                errors.Add("Employee number is required.");
            }

            return errors;
        }
    }
}
