using System;
using EduNova.Domain.Enums;

namespace EduNova.Domain.Entities
{
    public class Attendance : BaseEntity
    {
        public int StudentId { get; set; }
        public DateTime Date { get; set; }
        public AttendanceStatus Status { get; set; }
        public int MarkedByUserId { get; set; }
        public Student Student { get; set; }
        public User MarkedByUser { get; set; }
    }
}
