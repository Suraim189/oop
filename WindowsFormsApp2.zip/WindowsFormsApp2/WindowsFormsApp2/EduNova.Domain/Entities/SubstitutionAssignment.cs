using System;
using EduNova.Domain.Enums;

namespace EduNova.Domain.Entities
{
    public class SubstitutionAssignment : BaseEntity
    {
        public int EntryId { get; set; }
        public DateTime Date { get; set; }
        public int OriginalTeacherId { get; set; }
        public int SubstituteTeacherId { get; set; }
        public string Reason { get; set; }
        public LeaveStatus Status { get; set; }
        public TimetableEntry TimetableEntry { get; set; }
        public Teacher OriginalTeacher { get; set; }
        public Teacher SubstituteTeacher { get; set; }
    }
}
