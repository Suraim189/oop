namespace EduNova.Domain.Entities
{
    public class FeeStructure : BaseEntity
    {
        public int ClassSectionId { get; set; }
        public decimal MonthlyFee { get; set; }
        public decimal? AdmissionFee { get; set; }
        public decimal? MiscFee { get; set; }
        public ClassSection ClassSection { get; set; }
    }
}
