namespace EduNova.Domain.Entities
{
    public class ClassSection : BaseEntity
    {
        public int GradeClassId { get; set; }
        public int SectionId { get; set; }
        public int SessionYear { get; set; }
        public bool IsActive { get; set; }
        public GradeClass GradeClass { get; set; }
        public Section Section { get; set; }
    }
}
