using System;

namespace EduNova.Domain.Entities
{
    public class SchoolScheduleConfig : BaseEntity
    {
        public DateTime EffectiveFromDate { get; set; }
        public TimeSpan SchoolStartTime { get; set; }
        public TimeSpan SchoolEndTime { get; set; }
        public int LectureMinutes { get; set; }
        public int BreakMinutes { get; set; }
        public int BreakAfterPeriodIndex { get; set; }
        public bool IsActive { get; set; }
    }
}
