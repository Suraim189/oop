namespace EduNova.Domain.Entities
{
    public class BookCopy : BaseEntity
    {
        public int BookId { get; set; }
        public string CopyNo { get; set; }
        public bool IsAvailable { get; set; }
        public Book Book { get; set; }
    }
}
