namespace EduNova.Domain.Entities
{
    public class GradeClass : BaseEntity
    {
        public int GradeNumber { get; set; }
        public string DisplayName { get; set; }
    }
}
