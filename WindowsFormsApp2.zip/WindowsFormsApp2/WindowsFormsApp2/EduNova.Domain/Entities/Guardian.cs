namespace EduNova.Domain.Entities
{
    public class Guardian : BaseEntity
    {
        public string Name { get; set; }
        public string Phone { get; set; }
        public string Relation { get; set; }
    }
}
