using System;
using EduNova.Domain.Enums;

namespace EduNova.Domain.Entities
{
    public class Notification : BaseEntity
    {
        public int ToUserId { get; set; }
        public string Title { get; set; }
        public string Message { get; set; }
        public NotificationType Type { get; set; }
        public bool IsRead { get; set; }
        public DateTime CreatedAtUtc { get; set; }
        public User ToUser { get; set; }
    }
}
