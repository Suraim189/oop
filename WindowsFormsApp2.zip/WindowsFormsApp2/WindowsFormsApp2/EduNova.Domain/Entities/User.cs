using System.Collections.Generic;

namespace EduNova.Domain.Entities
{
    public class User : BaseEntity
    {
        public string Username { get; set; }
        public string DisplayName { get; set; }
        public string PasswordHash { get; set; }
        public int RoleId { get; set; }
        public bool IsActive { get; set; }
        public Role Role { get; set; }
        public List<Notification> Notifications { get; set; }
    }
}
