namespace EduNova.Domain.Enums
{
    public enum NotificationType
    {
        General,
        Attendance,
        Exam,
        Fee,
        Library,
        Timetable
    }
}
