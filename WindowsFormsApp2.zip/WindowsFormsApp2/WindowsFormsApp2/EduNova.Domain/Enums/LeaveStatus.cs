namespace EduNova.Domain.Enums
{
    public enum LeaveStatus
    {
        Pending,
        Approved,
        Rejected
    }
}
