namespace EduNova.Domain.Enums
{
    public enum ExamTerm
    {
        Monthly,
        HalfBook,
        FullBook
    }
}
