namespace EduNova.Domain.Enums
{
    public enum UserRole
    {
        Admin,
        Staff,
        Teacher
    }
}
