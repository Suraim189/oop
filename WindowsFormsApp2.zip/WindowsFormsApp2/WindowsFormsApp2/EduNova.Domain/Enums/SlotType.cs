namespace EduNova.Domain.Enums
{
    public enum SlotType
    {
        Lecture,
        Break
    }
}
