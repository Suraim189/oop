namespace EduNova.Domain.DTOs
{
    public class LoginResultDTO
    {
        public int UserId { get; set; }
        public string DisplayName { get; set; }
        public int RoleId { get; set; }
        public bool IsSuccess { get; set; }
        public string Message { get; set; }
    }
}
