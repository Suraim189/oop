namespace EduNova.Domain.DTOs
{
    public class ExamResultReportRowDTO
    {
        public string StudentName { get; set; }
        public string ExamName { get; set; }
        public string SubjectName { get; set; }
        public decimal ObtainedMarks { get; set; }
        public decimal TotalMarks { get; set; }
    }
}
