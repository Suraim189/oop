using System;

namespace EduNova.Domain.DTOs
{
    public class SubstitutionReportRowDTO
    {
        public DateTime Date { get; set; }
        public string ClassSection { get; set; }
        public string SubjectName { get; set; }
        public string OriginalTeacher { get; set; }
        public string SubstituteTeacher { get; set; }
    }
}
