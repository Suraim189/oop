namespace EduNova.Domain.DTOs
{
    public class AttendanceReportRowDTO
    {
        public string StudentName { get; set; }
        public string ClassSection { get; set; }
        public int TotalDays { get; set; }
        public int PresentDays { get; set; }
        public int AbsentDays { get; set; }
    }
}
