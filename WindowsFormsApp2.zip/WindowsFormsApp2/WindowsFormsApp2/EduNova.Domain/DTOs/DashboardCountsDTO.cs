namespace EduNova.Domain.DTOs
{
    public class DashboardCountsDTO
    {
        public int StudentsCount { get; set; }
        public int TeachersCount { get; set; }
        public int ClassesCount { get; set; }
        public int NotificationsUnread { get; set; }
    }
}
