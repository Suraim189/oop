namespace EduNova.Domain.DTOs
{
    public class FeeDueReportRowDTO
    {
        public string StudentName { get; set; }
        public string ClassSection { get; set; }
        public decimal TotalAmount { get; set; }
        public decimal PaidAmount { get; set; }
        public decimal DueAmount { get; set; }
    }
}
