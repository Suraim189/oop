using System.Drawing;
using System.Windows.Forms;

namespace EduNova.WinForms
{
    public class ToastControl : UserControl
    {
        private readonly Label _label;

        public ToastControl()
        {
            BackColor = Theme.Accent;
            Height = 40;
            Dock = DockStyle.Top;
            _label = new Label
            {
                ForeColor = Theme.TextPrimary,
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(12, 0, 0, 0)
            };
            Controls.Add(_label);
        }

        public void ShowMessage(string message)
        {
            _label.Text = message;
            Visible = true;
        }
    }
}
