using System.Drawing;

namespace EduNova.WinForms
{
    public static class Theme
    {
        public static readonly Color Background = Color.FromArgb(18, 22, 34);
        public static readonly Color Panel = Color.FromArgb(24, 30, 48);
        public static readonly Color Accent = Color.FromArgb(65, 105, 225);
        public static readonly Color AccentHover = Color.FromArgb(90, 130, 245);
        public static readonly Color TextPrimary = Color.WhiteSmoke;
        public static readonly Color TextSecondary = Color.Gainsboro;
    }
}
