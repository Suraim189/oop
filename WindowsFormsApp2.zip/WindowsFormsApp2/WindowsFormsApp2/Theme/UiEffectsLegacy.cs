using System.Drawing;
using System.Windows.Forms;

namespace EduNova.WinForms
{
    public static class UiEffects
    {
        public static void ApplyHover(Control control)
        {
            control.MouseEnter += (s, e) => control.BackColor = Theme.AccentHover;
            control.MouseLeave += (s, e) => control.BackColor = Theme.Accent;
        }

        public static void ApplyGlow(Panel panel)
        {
            var timer = new Timer { Interval = 30 };
            var grow = true;
            timer.Tick += (s, e) =>
            {
                var delta = grow ? 2 : -2;
                panel.Padding = new Padding(
                    panel.Padding.Left + delta,
                    panel.Padding.Top + delta,
                    panel.Padding.Right + delta,
                    panel.Padding.Bottom + delta);
                if (panel.Padding.Left >= 6) grow = false;
                if (panel.Padding.Left <= 2) grow = true;
            };
            timer.Start();
        }
    }
}
