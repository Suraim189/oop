using System.Configuration;

namespace EduNova.Data
{
    public static class Db
    {
        public static string ConnectionString
        {
            get
            {
                return ConfigurationManager.ConnectionStrings["EduNovaDBss"]?.ConnectionString;
            }
        }
    }
}
