﻿using System;
using System.Data;
using EduNova.Domain.Entities;

namespace EduNova.Data.Mappers
{
    public static class StudentMapper
    {
        public static Student Map(DataRow row)
        {
            return new Student
            {
                AdmissionNo = row["AdmissionNo"].ToString(),
                RollNo = row["RollNo"] == DBNull.Value ? 0 : (int)row["RollNo"],
                Age = (int)row["Age"],
                IsActive = row["IsActive"] != DBNull.Value && (bool)row["IsActive"],
                FirstName = row["FirstName"].ToString(),
                LastName = row["LastName"].ToString()
            };
        }
    }
}
