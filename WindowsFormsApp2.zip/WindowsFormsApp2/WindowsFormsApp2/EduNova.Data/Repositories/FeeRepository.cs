using System.Data;
using System.Data.SqlClient;

namespace EduNova.Data.Repositories
{
    public class FeeRepository
    {
        public void GenerateFeeVouchers(int month, int year)
        {
            SqlHelper.ExecuteNonQuery("sp_GenerateFeeVouchers",
                new SqlParameter("@Month", month),
                new SqlParameter("@Year", year));
        }

        public void PayVoucher(int voucherId, decimal paidAmount, System.DateTime paidOn, string method, int receivedByUserId)
        {
            SqlHelper.ExecuteNonQuery("sp_PayFeeVoucher",
                new SqlParameter("@VoucherId", voucherId),
                new SqlParameter("@PaidAmount", paidAmount),
                new SqlParameter("@PaidOn", paidOn),
                new SqlParameter("@Method", method),
                new SqlParameter("@ReceivedByUserId", receivedByUserId));
        }

        public DataTable GetFeeDueStudents()
        {
            return SqlHelper.ExecuteDataTable("sp_GetFeeDueStudents");
        }
    }
}
