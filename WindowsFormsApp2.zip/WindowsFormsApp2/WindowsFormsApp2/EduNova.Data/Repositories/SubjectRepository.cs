﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using EduNova.Domain.Entities;

namespace EduNova.Data.Repositories
{
    public class SubjectRepository
    {
        public List<Subject> GetAll()
        {
            var table = SqlHelper.ExecuteDataTable("sp_Subject_Get");
            var result = new List<Subject>();

            foreach (DataRow row in table.Rows)
            {
                result.Add(new Subject
                {
                    Id = (int)row["SubjectId"],
                    DomainId = (int)row["DomainId"],
                    Name = row["Name"].ToString(),
                    Code = row["Code"].ToString(),
                    IsActive = row["IsActive"] != DBNull.Value && (bool)row["IsActive"]
                });
            }

            return result;
        }
    }
}
