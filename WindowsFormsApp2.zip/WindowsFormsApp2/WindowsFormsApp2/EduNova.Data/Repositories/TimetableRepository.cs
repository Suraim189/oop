using System.Data;
using System.Data.SqlClient;
using EduNova.Domain.Entities;

namespace EduNova.Data.Repositories
{
    public class TimetableRepository
    {
        public void SaveEntry(TimetableEntry entry)
        {
            SqlHelper.ExecuteNonQuery("sp_TimetableEntry_CRUD",
                new SqlParameter("@Action", "INSERT"),
                new SqlParameter("@ClassSectionId", entry.ClassSectionId),
                new SqlParameter("@DayOfWeek", entry.DayOfWeek),
                new SqlParameter("@TimeSlotId", entry.TimeSlotId),
                new SqlParameter("@SubjectId", entry.SubjectId),
                new SqlParameter("@TeacherId", entry.TeacherId),
                new SqlParameter("@Room", entry.Room));
        }

        public DataTable GetTeacherSchedule(int teacherId)
        {
            return SqlHelper.ExecuteDataTable("sp_TeacherSchedule_Get", new SqlParameter("@TeacherId", teacherId));
        }
    }
}
