using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using EduNova.Data.Mappers;
using EduNova.Domain.Entities;
using EduNova.Domain.Interfaces;

namespace EduNova.Data.Repositories
{
    public class StudentRepository : IRepository<Student>
    {
        public void Add(Student entity)
        {
            SqlHelper.ExecuteNonQuery("sp_Student_Insert",
                new SqlParameter("@FirstName", entity.FirstName),
                new SqlParameter("@LastName", entity.LastName),
                new SqlParameter("@AdmissionNo", entity.AdmissionNo),
                new SqlParameter("@RollNo", entity.RollNo),
                new SqlParameter("@Age", entity.Age));
        }

        public void Update(Student entity)
        {
            SqlHelper.ExecuteNonQuery("sp_Student_Update",
                new SqlParameter("@StudentId", entity.Id),
                new SqlParameter("@FirstName", entity.FirstName),
                new SqlParameter("@LastName", entity.LastName),
                new SqlParameter("@AdmissionNo", entity.AdmissionNo),
                new SqlParameter("@RollNo", entity.RollNo),
                new SqlParameter("@Age", entity.Age),
                new SqlParameter("@IsActive", entity.IsActive));
        }

        public void Delete(int id)
        {
            SqlHelper.ExecuteNonQuery("sp_Student_Delete", new SqlParameter("@StudentId", id));
        }

        public Student GetById(int id)
        {
            var table = SqlHelper.ExecuteDataTable("sp_Student_Get", new SqlParameter("@StudentId", id));
            return table.Rows.Count == 0 ? null : StudentMapper.Map(table.Rows[0]);
        }

        public List<Student> GetAll()
        {
            var table = SqlHelper.ExecuteDataTable("sp_Student_Get");
            var result = new List<Student>();

            foreach (DataRow row in table.Rows)
            {
                result.Add(StudentMapper.Map(row));
            }

            return result;
        }
    }
}
