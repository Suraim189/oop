using System.Data;
using System.Data.SqlClient;

namespace EduNova.Data.Repositories
{
    public class NotificationRepository
    {
        public void CreateNotification(int toUserId, string title, string message, string type)
        {
            SqlHelper.ExecuteNonQuery("sp_CreateNotification",
                new SqlParameter("@ToUserId", toUserId),
                new SqlParameter("@Title", title),
                new SqlParameter("@Message", message),
                new SqlParameter("@Type", type));
        }

        public DataTable GetUnreadNotifications(int toUserId)
        {
            return SqlHelper.ExecuteDataTable("sp_GetUnreadNotifications", new SqlParameter("@ToUserId", toUserId));
        }
    }
}
