using System;
using System.Data.SqlClient;

namespace EduNova.Data.Repositories
{
    public class AttendanceRepository
    {
        public void SaveAttendance(int studentId, DateTime date, string status, int markedByUserId)
        {
            SqlHelper.ExecuteNonQuery("sp_SaveAttendance",
                new SqlParameter("@StudentId", studentId),
                new SqlParameter("@Date", date),
                new SqlParameter("@Status", status),
                new SqlParameter("@MarkedByUserId", markedByUserId));
        }
    }
}
