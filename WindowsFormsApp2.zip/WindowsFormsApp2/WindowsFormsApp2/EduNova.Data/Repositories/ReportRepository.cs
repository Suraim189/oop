using System.Data;

namespace EduNova.Data.Repositories
{
    public class ReportRepository
    {
        public DataTable GetDashboardCounts()
        {
            return SqlHelper.ExecuteDataTable("sp_GetDashboardCounts");
        }

        public DataTable GetFeeDueReport()
        {
            return SqlHelper.ExecuteDataTable("sp_GetFeeDueStudents");
        }

        public DataTable GetExamResultReport()
        {
            return SqlHelper.ExecuteDataTable("sp_GetExamResultReport");
        }
    }
}
