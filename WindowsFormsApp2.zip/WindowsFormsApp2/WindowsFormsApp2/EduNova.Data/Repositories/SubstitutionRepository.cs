using System.Data;
using System.Data.SqlClient;

namespace EduNova.Data.Repositories
{
    public class SubstitutionRepository
    {
        public int FindSubstitute(int subjectId, int domainId, int timeSlotId, int dayOfWeek)
        {
            var result = SqlHelper.ExecuteScalar("sp_FindSubstituteTeacher",
                new SqlParameter("@SubjectId", subjectId),
                new SqlParameter("@DomainId", domainId),
                new SqlParameter("@TimeSlotId", timeSlotId),
                new SqlParameter("@DayOfWeek", dayOfWeek));

            return result == null ? 0 : (int)result;
        }

        public void AssignSubstitution(int entryId, System.DateTime date, int originalTeacherId, int substituteTeacherId, string reason)
        {
            SqlHelper.ExecuteNonQuery("sp_AssignSubstitution",
                new SqlParameter("@EntryId", entryId),
                new SqlParameter("@Date", date),
                new SqlParameter("@OriginalTeacherId", originalTeacherId),
                new SqlParameter("@SubstituteTeacherId", substituteTeacherId),
                new SqlParameter("@Reason", reason));
        }
    }
}
