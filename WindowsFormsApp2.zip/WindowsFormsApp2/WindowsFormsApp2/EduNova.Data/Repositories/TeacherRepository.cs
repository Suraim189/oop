﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using EduNova.Domain.Entities;
using EduNova.Domain.Interfaces;

namespace EduNova.Data.Repositories
{
    public class TeacherRepository : IRepository<Teacher>
    {
        public void Add(Teacher entity)
        {
            SqlHelper.ExecuteNonQuery("sp_Teacher_Insert",
                new SqlParameter("@FirstName", entity.FirstName),
                new SqlParameter("@LastName", entity.LastName),
                new SqlParameter("@EmployeeNo", entity.EmployeeNo));
        }

        public void Update(Teacher entity)
        {
            SqlHelper.ExecuteNonQuery("sp_Teacher_Update",
                new SqlParameter("@TeacherId", entity.Id),
                new SqlParameter("@FirstName", entity.FirstName),
                new SqlParameter("@LastName", entity.LastName),
                new SqlParameter("@EmployeeNo", entity.EmployeeNo),
                new SqlParameter("@IsActive", entity.IsActive));
        }

        public void Delete(int id)
        {
            SqlHelper.ExecuteNonQuery("sp_Teacher_Delete", new SqlParameter("@TeacherId", id));
        }

        public Teacher GetById(int id)
        {
            var table = SqlHelper.ExecuteDataTable("sp_Teacher_Get", new SqlParameter("@TeacherId", id));
            if (table.Rows.Count == 0)
            {
                return null;
            }

            var row = table.Rows[0];
            return new Teacher
            {
                Id = (int)row["TeacherId"],
                FirstName = row["FirstName"].ToString(),
                LastName = row["LastName"].ToString(),
                EmployeeNo = row["EmployeeNo"].ToString(),
                IsActive = row["IsActive"] != DBNull.Value && (bool)row["IsActive"]
            };
        }

        public List<Teacher> GetAll()
        {
            var table = SqlHelper.ExecuteDataTable("sp_Teacher_Get");
            var result = new List<Teacher>();

            foreach (DataRow row in table.Rows)
            {
                result.Add(new Teacher
                {
                    Id = (int)row["TeacherId"],
                    FirstName = row["FirstName"].ToString(),
                    LastName = row["LastName"].ToString(),
                    EmployeeNo = row["EmployeeNo"].ToString(),
                    IsActive = row["IsActive"] != DBNull.Value && (bool)row["IsActive"]
                });
            }

            return result;
        }
    }
}
