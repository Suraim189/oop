using System.Data;
using System.Data.SqlClient;

namespace EduNova.Data.Repositories
{
    public class LeaveRepository
    {
        public DataTable RequestLeave(int teacherId, System.DateTime leaveDate, string reason)
        {
            return SqlHelper.ExecuteDataTable("sp_RequestTeacherLeave",
                new SqlParameter("@TeacherId", teacherId),
                new SqlParameter("@LeaveDate", leaveDate),
                new SqlParameter("@Reason", reason));
        }
    }
}
