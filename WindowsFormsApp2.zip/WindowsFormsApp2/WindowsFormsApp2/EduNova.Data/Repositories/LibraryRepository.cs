using System.Data.SqlClient;

namespace EduNova.Data.Repositories
{
    public class LibraryRepository
    {
        public void IssueBook(int copyId, int studentId, System.DateTime issuedOn, System.DateTime dueOn)
        {
            SqlHelper.ExecuteNonQuery("sp_Library_IssueBook",
                new SqlParameter("@CopyId", copyId),
                new SqlParameter("@StudentId", studentId),
                new SqlParameter("@IssuedOn", issuedOn),
                new SqlParameter("@DueOn", dueOn));
        }

        public void ReturnBook(int issueId, System.DateTime returnedOn, decimal fineAmount)
        {
            SqlHelper.ExecuteNonQuery("sp_Library_ReturnBook",
                new SqlParameter("@IssueId", issueId),
                new SqlParameter("@ReturnedOn", returnedOn),
                new SqlParameter("@FineAmount", fineAmount));
        }
    }
}
