using System.Data;
using System.Data.SqlClient;

namespace EduNova.Data.Repositories
{
    public class AdminRepository
    {
        public DataTable Login(string username, string password)
        {
            return SqlHelper.ExecuteDataTable("sp_LoginUser",
                new SqlParameter("@username", username),
                new SqlParameter("@password", password));
        }

        public DataTable GetPermissions(int userId)
        {
            return SqlHelper.ExecuteDataTable("sp_GetUserPermissions", new SqlParameter("@userId", userId));
        }
    }
}
