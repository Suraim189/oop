﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using EduNova.Domain.Entities;

namespace EduNova.Data.Repositories
{
    public class ClassSectionRepository
    {
        public List<ClassSection> GetAll()
        {
            var table = SqlHelper.ExecuteDataTable("sp_ClassSection_Get");
            var result = new List<ClassSection>();

            foreach (DataRow row in table.Rows)
            {
                result.Add(new ClassSection
                {
                    Id = (int)row["ClassSectionId"],
                    GradeClassId = (int)row["GradeClassId"],
                    SectionId = (int)row["SectionId"],
                    SessionYear = (int)row["SessionYear"],
                    IsActive = row["IsActive"] != DBNull.Value && (bool)row["IsActive"]
                });
            }

            return result;
        }
    }
}
