using System.Data;
using System.Data.SqlClient;

namespace EduNova.Data.Repositories
{
    public class ExamRepository
    {
        public void CreateExam(int examTypeId, int classSectionId, int subjectId, System.DateTime examDate, decimal totalMarks)
        {
            SqlHelper.ExecuteNonQuery("sp_CreateExam",
                new SqlParameter("@ExamTypeId", examTypeId),
                new SqlParameter("@ClassSectionId", classSectionId),
                new SqlParameter("@SubjectId", subjectId),
                new SqlParameter("@ExamDate", examDate),
                new SqlParameter("@TotalMarks", totalMarks));
        }

        public void SaveMarks(int examId, int studentId, decimal obtainedMarks)
        {
            SqlHelper.ExecuteNonQuery("sp_SaveMarks",
                new SqlParameter("@ExamId", examId),
                new SqlParameter("@StudentId", studentId),
                new SqlParameter("@ObtainedMarks", obtainedMarks));
        }

        public DataTable GetExamResultReport()
        {
            return SqlHelper.ExecuteDataTable("sp_GetExamResultReport");
        }
    }
}
