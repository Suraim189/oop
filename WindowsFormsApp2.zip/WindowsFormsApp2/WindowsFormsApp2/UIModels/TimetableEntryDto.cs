namespace EduNova.WinForms.UIModels
{
    public class TimetableEntryDto
    {
        public int Id { get; set; }
        public string ClassSection { get; set; }
        public string DayOfWeek { get; set; }
        public string TimeSlot { get; set; }
        public string Subject { get; set; }
        public string Teacher { get; set; }
        public string Room { get; set; }
    }
}
