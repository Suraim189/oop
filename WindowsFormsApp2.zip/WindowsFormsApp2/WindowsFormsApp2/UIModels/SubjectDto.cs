namespace EduNova.WinForms.UIModels
{
    public class SubjectDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Code { get; set; }
        public string Domain { get; set; }
        public bool IsActive { get; set; }
    }
}
