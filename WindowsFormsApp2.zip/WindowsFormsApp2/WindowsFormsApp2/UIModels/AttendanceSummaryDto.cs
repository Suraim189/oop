namespace EduNova.WinForms.UIModels
{
    public class AttendanceSummaryDto
    {
        public string StudentName { get; set; }
        public int TotalDays { get; set; }
        public int PresentDays { get; set; }
        public int AbsentDays { get; set; }
    }
}
