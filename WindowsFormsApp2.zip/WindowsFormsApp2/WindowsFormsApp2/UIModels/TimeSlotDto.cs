using System;

namespace EduNova.WinForms.UIModels
{
    public class TimeSlotDto
    {
        public int Id { get; set; }
        public int PeriodIndex { get; set; }
        public TimeSpan StartTime { get; set; }
        public TimeSpan EndTime { get; set; }
        public string SlotType { get; set; }
    }
}
