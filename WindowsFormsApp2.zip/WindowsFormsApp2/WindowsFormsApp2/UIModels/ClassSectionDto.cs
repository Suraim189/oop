namespace EduNova.WinForms.UIModels
{
    public class ClassSectionDto
    {
        public int Id { get; set; }
        public string Grade { get; set; }
        public string Section { get; set; }
        public int SessionYear { get; set; }
        public bool IsActive { get; set; }
    }
}
