using System.Collections.Generic;

namespace EduNova.WinForms.UIModels
{
    public class ResultCardDto
    {
        public string StudentName { get; set; }
        public string ClassSection { get; set; }
        public string ExamTerm { get; set; }
        public List<ResultRowDto> Subjects { get; set; }
        public decimal TotalMarks { get; set; }
        public decimal ObtainedMarks { get; set; }
        public decimal Percentage { get; set; }
        public string Grade { get; set; }
    }
}
