namespace EduNova.WinForms.UIModels
{
    public class SubjectDomainDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
