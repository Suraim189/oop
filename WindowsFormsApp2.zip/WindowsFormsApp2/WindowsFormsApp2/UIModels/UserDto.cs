namespace EduNova.WinForms.UIModels
{
    public class UserDto
    {
        public int Id { get; set; }
        public string Username { get; set; }
        public string DisplayName { get; set; }
        public string Role { get; set; }
        public bool IsActive { get; set; }
    }
}
