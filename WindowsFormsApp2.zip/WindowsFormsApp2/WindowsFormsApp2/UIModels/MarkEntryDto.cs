namespace EduNova.WinForms.UIModels
{
    public class MarkEntryDto
    {
        public int ExamId { get; set; }
        public int StudentId { get; set; }
        public string StudentName { get; set; }
        public decimal ObtainedMarks { get; set; }
    }
}
