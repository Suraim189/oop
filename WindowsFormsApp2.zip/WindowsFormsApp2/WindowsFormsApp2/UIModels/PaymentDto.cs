using System;

namespace EduNova.WinForms.UIModels
{
    public class PaymentDto
    {
        public int Id { get; set; }
        public int VoucherId { get; set; }
        public decimal PaidAmount { get; set; }
        public DateTime PaidOn { get; set; }
        public string Method { get; set; }
    }
}
