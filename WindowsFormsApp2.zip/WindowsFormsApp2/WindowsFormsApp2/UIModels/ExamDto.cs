using System;

namespace EduNova.WinForms.UIModels
{
    public class ExamDto
    {
        public int Id { get; set; }
        public string ExamType { get; set; }
        public string ClassSection { get; set; }
        public string Subject { get; set; }
        public DateTime ExamDate { get; set; }
        public decimal TotalMarks { get; set; }
    }
}
