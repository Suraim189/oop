namespace EduNova.WinForms.UIModels
{
    public class StudentGridRowDto
    {
        public int Id { get; set; }
        public string AdmissionNo { get; set; }
        public string FullName { get; set; }
        public int Age { get; set; }
        public string ClassSection { get; set; }
        public string Phone { get; set; }
        public string FeeStatus { get; set; }
    }
}
