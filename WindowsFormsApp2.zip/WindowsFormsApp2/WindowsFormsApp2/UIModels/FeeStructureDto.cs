namespace EduNova.WinForms.UIModels
{
    public class FeeStructureDto
    {
        public int Id { get; set; }
        public string ClassSection { get; set; }
        public decimal MonthlyFee { get; set; }
        public decimal? AdmissionFee { get; set; }
        public decimal? MiscFee { get; set; }
    }
}
