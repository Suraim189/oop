namespace EduNova.WinForms.UIModels
{
    public class FeeDueRowDto
    {
        public int StudentId { get; set; }
        public string StudentName { get; set; }
        public decimal TotalAmount { get; set; }
        public decimal PaidAmount { get; set; }
        public decimal DueAmount { get; set; }
    }
}
