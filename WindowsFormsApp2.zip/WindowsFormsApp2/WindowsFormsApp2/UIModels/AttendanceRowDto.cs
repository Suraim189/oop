using System;

namespace EduNova.WinForms.UIModels
{
    public class AttendanceRowDto
    {
        public int StudentId { get; set; }
        public string StudentName { get; set; }
        public DateTime Date { get; set; }
        public string Status { get; set; }
    }
}
