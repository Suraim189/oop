using System;

namespace EduNova.WinForms.UIModels
{
    public class StudentEditDto
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int Age { get; set; }
        public DateTime? Dob { get; set; }
        public string GuardianName { get; set; }
        public int ClassSectionId { get; set; }
        public bool IsActive { get; set; }
    }
}
