using System;

namespace EduNova.WinForms.UIModels
{
    public class LeaveRequestDto
    {
        public int TeacherId { get; set; }
        public DateTime LeaveDate { get; set; }
        public string Reason { get; set; }
    }
}
