using System;

namespace EduNova.WinForms.UIModels
{
    public class SubstitutionDto
    {
        public int Id { get; set; }
        public DateTime Date { get; set; }
        public string ClassSection { get; set; }
        public string Subject { get; set; }
        public string OriginalTeacher { get; set; }
        public string SubstituteTeacher { get; set; }
    }
}
