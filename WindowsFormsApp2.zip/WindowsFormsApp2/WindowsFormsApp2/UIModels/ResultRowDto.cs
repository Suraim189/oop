namespace EduNova.WinForms.UIModels
{
    public class ResultRowDto
    {
        public string StudentName { get; set; }
        public string Subject { get; set; }
        public decimal ObtainedMarks { get; set; }
        public decimal TotalMarks { get; set; }
    }
}
