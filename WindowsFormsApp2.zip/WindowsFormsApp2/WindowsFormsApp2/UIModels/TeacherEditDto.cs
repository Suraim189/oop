namespace EduNova.WinForms.UIModels
{
    public class TeacherEditDto
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string EmployeeNo { get; set; }
        public string Qualification { get; set; }
        public bool IsActive { get; set; }
    }
}
