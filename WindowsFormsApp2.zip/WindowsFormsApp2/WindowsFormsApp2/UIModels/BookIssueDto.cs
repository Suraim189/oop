using System;

namespace EduNova.WinForms.UIModels
{
    public class BookIssueDto
    {
        public int Id { get; set; }
        public string BookTitle { get; set; }
        public string StudentName { get; set; }
        public DateTime IssuedOn { get; set; }
        public DateTime DueOn { get; set; }
        public DateTime? ReturnedOn { get; set; }
        public decimal FineAmount { get; set; }
    }
}
