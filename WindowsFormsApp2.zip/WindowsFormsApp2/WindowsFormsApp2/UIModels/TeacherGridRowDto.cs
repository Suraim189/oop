namespace EduNova.WinForms.UIModels
{
    public class TeacherGridRowDto
    {
        public int Id { get; set; }
        public string EmployeeNo { get; set; }
        public string FullName { get; set; }
        public string Qualification { get; set; }
        public bool IsActive { get; set; }
    }
}
