namespace EduNova.WinForms.UIModels
{
    public class BookDto
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Isbn { get; set; }
        public string Author { get; set; }
        public string Category { get; set; }
        public bool IsActive { get; set; }
    }
}
