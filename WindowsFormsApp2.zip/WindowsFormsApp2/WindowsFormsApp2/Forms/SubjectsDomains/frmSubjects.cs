using System.Drawing;
using System.Windows.Forms;

namespace EduNova.WinForms
{
    public class frmSubjects : Form
    {
        public frmSubjects()
        {
            Text = "Subjects & Domains";
            BackColor = Theme.Background;
            Size = new Size(800, 500);

            var grid = new DataGridView { Dock = DockStyle.Fill, BackgroundColor = Theme.Panel };
            Controls.Add(grid);
        }
    }
}
