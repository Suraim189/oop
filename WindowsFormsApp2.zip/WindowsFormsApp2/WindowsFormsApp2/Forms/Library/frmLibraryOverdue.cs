using System.Drawing;
using System.Windows.Forms;

namespace EduNova.WinForms
{
    public class frmLibraryOverdue : Form
    {
        public frmLibraryOverdue()
        {
            Text = "Library Overdue";
            BackColor = Theme.Background;
            Size = new Size(900, 600);

            var grid = new DataGridView { Dock = DockStyle.Fill, BackgroundColor = Theme.Panel };
            Controls.Add(grid);
        }
    }
}
