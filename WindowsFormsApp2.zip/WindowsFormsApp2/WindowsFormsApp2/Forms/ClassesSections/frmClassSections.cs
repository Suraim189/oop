using System.Drawing;
using System.Windows.Forms;

namespace EduNova.WinForms
{
    public class frmClassSections : Form
    {
        public frmClassSections()
        {
            Text = "Classes & Sections";
            BackColor = Theme.Background;
            Size = new Size(800, 500);

            var grid = new DataGridView { Dock = DockStyle.Fill, BackgroundColor = Theme.Panel };
            Controls.Add(grid);
        }
    }
}
