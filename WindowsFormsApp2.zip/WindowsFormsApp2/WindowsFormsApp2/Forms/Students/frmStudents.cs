using System;
using System.Drawing;
using System.Windows.Forms;
using EduNova.Services;
using System.Runtime.InteropServices;

namespace EduNova.WinForms
{
    public class frmStudents : Form
    {
        private readonly DataGridView _grid;
        private readonly TextBox _txtName;
        private readonly TextBox _txtAge;
        private readonly ErrorProvider _errors;
        private readonly StudentService _service = new StudentService();

        // WinAPI: TextBox "placeholder" (Cue Banner) for .NET Framework
        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        private static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wParam, string lParam);

        private const int EM_SETCUEBANNER = 0x1501;

        public frmStudents()
        {
            Text = "Students";
            BackColor = Theme.Background;
            Size = new Size(900, 600);

            // ErrorProvider setup
            _errors = new ErrorProvider
            {
                ContainerControl = this
            };

            // NOTE: .NET Framework 4.8 TextBox does NOT have PlaceholderText
            _txtName = new TextBox { Dock = DockStyle.Top };
            _txtAge = new TextBox { Dock = DockStyle.Top };

            var btnSave = new Button
            {
                Text = "Save",
                BackColor = Theme.Accent,
                ForeColor = Theme.TextPrimary,
                Height = 36,
                Dock = DockStyle.Top
            };

            UiEffects.ApplyHover(btnSave);
            btnSave.Click += (s, e) => SaveStudent();

            _grid = new DataGridView
            {
                Dock = DockStyle.Fill,
                BackgroundColor = Theme.Panel
            };

            var panel = new Panel
            {
                Dock = DockStyle.Left,
                Width = 260,
                BackColor = Theme.Panel,
                Padding = new Padding(12)
            };

            panel.Controls.Add(btnSave);
            panel.Controls.Add(_txtAge);
            panel.Controls.Add(_txtName);

            Controls.Add(_grid);
            Controls.Add(panel);

            // Apply placeholders AFTER controls have handles created.
            Shown += (s, e) =>
            {
                SetPlaceholder(_txtName, "Student Name");
                SetPlaceholder(_txtAge, "Age");
            };
        }

        private void SetPlaceholder(TextBox textBox, string placeholder)
        {
            if (textBox == null) return;

            // wParam = 1 => show cue banner even when focused (optional)
            SendMessage(textBox.Handle, EM_SETCUEBANNER, (IntPtr)1, placeholder);
        }

        private void SaveStudent()
        {
            _errors.Clear();

            if (string.IsNullOrWhiteSpace(_txtName.Text))
            {
                _errors.SetError(_txtName, "Name is required.");
                return;
            }

            if (!int.TryParse(_txtAge.Text, out var age) || age <= 0)
            {
                _errors.SetError(_txtAge, "Valid age required.");
                return;
            }

            // (Optional) Save logic if your service supports it
            // Example (depends on your StudentService API):
            // _service.Save(new Student { Name = _txtName.Text.Trim(), Age = age });
        }
    }
}