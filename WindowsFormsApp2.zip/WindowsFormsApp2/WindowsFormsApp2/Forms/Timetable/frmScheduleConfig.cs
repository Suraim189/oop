using System;
using System.Drawing;
using System.Windows.Forms;

namespace EduNova.WinForms
{
    public class frmScheduleConfig : Form
    {
        public frmScheduleConfig()
        {
            Text = "Schedule Config";
            BackColor = Theme.Background;
            Size = new Size(800, 500);

            var datePicker = new DateTimePicker { Dock = DockStyle.Top };
            var btnSave = new Button
            {
                Text = "Save Config",
                BackColor = Theme.Accent,
                ForeColor = Theme.TextPrimary,
                Dock = DockStyle.Top,
                Height = 36
            };
            UiEffects.ApplyHover(btnSave);

            Controls.Add(btnSave);
            Controls.Add(datePicker);
        }
    }
}
