using System;
using System.Drawing;
using System.Windows.Forms;

namespace EduNova.WinForms
{
    public class frmTeacherLeaveRequest : Form
    {
        public frmTeacherLeaveRequest()
        {
            Text = "Teacher Leave Request";
            BackColor = Theme.Background;
            Size = new Size(700, 500);

            var dtLeave = new DateTimePicker { Dock = DockStyle.Top };
            var txtReason = new TextBox { Dock = DockStyle.Top };

            var btnRequest = new Button
            {
                Text = "Request Leave",
                BackColor = Theme.Accent,
                ForeColor = Theme.TextPrimary,
                Dock = DockStyle.Top,
                Height = 36
            };
            UiEffects.ApplyHover(btnRequest);

            Controls.Add(btnRequest);
            Controls.Add(txtReason);
            Controls.Add(dtLeave);
        }
    }
}
