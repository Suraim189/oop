using System.Drawing;
using System.Windows.Forms;

namespace EduNova.WinForms
{
    public class frmTimetableEditor : Form
    {
        public frmTimetableEditor()
        {
            Text = "Timetable Editor";
            BackColor = Theme.Background;
            Size = new Size(900, 600);

            var grid = new DataGridView { Dock = DockStyle.Fill, BackgroundColor = Theme.Panel };
            Controls.Add(grid);
        }
    }
}
