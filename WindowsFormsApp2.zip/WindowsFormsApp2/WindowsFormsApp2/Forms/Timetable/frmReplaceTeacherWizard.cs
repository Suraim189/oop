using System.Drawing;
using System.Windows.Forms;

namespace EduNova.WinForms
{
    public class frmReplaceTeacherWizard : Form
    {
        public frmReplaceTeacherWizard()
        {
            Text = "Replace Teacher Wizard";
            BackColor = Theme.Background;
            Size = new Size(600, 400);

            var lbl = new Label
            {
                Text = "Transfer only if new teacher is qualified for same subject.",
                ForeColor = Theme.TextSecondary,
                Dock = DockStyle.Top,
                Height = 40
            };

            var btnRun = new Button
            {
                Text = "Run Wizard",
                BackColor = Theme.Accent,
                ForeColor = Theme.TextPrimary,
                Dock = DockStyle.Top,
                Height = 36
            };
            UiEffects.ApplyHover(btnRun);

            Controls.Add(btnRun);
            Controls.Add(lbl);
        }
    }
}
