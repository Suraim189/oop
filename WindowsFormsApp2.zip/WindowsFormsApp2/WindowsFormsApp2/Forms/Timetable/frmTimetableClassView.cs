using System.Drawing;
using System.Windows.Forms;

namespace EduNova.WinForms
{
    public class frmTimetableClassView : Form
    {
        public frmTimetableClassView()
        {
            Text = "Class Timetable";
            BackColor = Theme.Background;
            Size = new Size(900, 600);

            var grid = new DataGridView { Dock = DockStyle.Fill, BackgroundColor = Theme.Panel };
            Controls.Add(grid);
        }
    }
}
