using System.Drawing;
using System.Drawing.Printing;
using System.Windows.Forms;

namespace EduNova.WinForms
{
    public class frmResultCard : Form
    {
        private readonly PrintDocument _printDocument;
        private readonly PrintPreviewDialog _previewDialog;

        public frmResultCard()
        {
            Text = "Result Card";
            BackColor = Theme.Background;
            Size = new Size(800, 600);

            var btnPrint = new Button
            {
                Text = "Print Preview",
                BackColor = Theme.Accent,
                ForeColor = Theme.TextPrimary,
                Dock = DockStyle.Top,
                Height = 36
            };
            UiEffects.ApplyHover(btnPrint);

            _printDocument = new PrintDocument();
            _printDocument.PrintPage += PrintDocument_PrintPage;

            _previewDialog = new PrintPreviewDialog
            {
                Document = _printDocument,
                Width = 800,
                Height = 600
            };

            btnPrint.Click += (s, e) => _previewDialog.ShowDialog();

            Controls.Add(btnPrint);
        }

        private void PrintDocument_PrintPage(object sender, PrintPageEventArgs e)
        {
            var g = e.Graphics;
            using (var brush = new SolidBrush(Color.Black))
            using (var font = new Font("Segoe UI", 12))
            {
                g.DrawString("Student Result Card", font, brush, 50, 50);
                g.DrawString("Student: __________", font, brush, 50, 90);
                g.DrawString("Class/Section: __________", font, brush, 50, 120);
                g.DrawString("Exam Term: __________", font, brush, 50, 150);
            }
        }
    }
}
