using System.Drawing;
using System.Windows.Forms;

namespace EduNova.WinForms
{
    public class frmFeeDueReport : Form
    {
        public frmFeeDueReport()
        {
            Text = "Fee Due Report";
            BackColor = Theme.Background;
            Size = new Size(900, 600);

            var grid = new DataGridView { Dock = DockStyle.Fill, BackgroundColor = Theme.Panel };
            Controls.Add(grid);
        }
    }
}
