using System.Drawing;
using System.Windows.Forms;

namespace EduNova.WinForms
{
    public class frmVoucherGenerate : Form
    {
        public frmVoucherGenerate()
        {
            Text = "Generate Vouchers";
            BackColor = Theme.Background;
            Size = new Size(900, 600);

            var btnGenerate = new Button
            {
                Text = "Generate",
                BackColor = Theme.Accent,
                ForeColor = Theme.TextPrimary,
                Dock = DockStyle.Top,
                Height = 36
            };
            UiEffects.ApplyHover(btnGenerate);

            var grid = new DataGridView { Dock = DockStyle.Fill, BackgroundColor = Theme.Panel };
            Controls.Add(grid);
            Controls.Add(btnGenerate);
        }
    }
}
