using System;
using System.Drawing;
using System.Windows.Forms;
using EduNova.Services;
using System.Runtime.InteropServices;

namespace EduNova.WinForms
{
    public class frmTeachers : Form
    {
        private readonly TextBox _txtName;
        private readonly TextBox _txtEmployeeNo;
        private readonly ErrorProvider _errors;
        private readonly TeacherService _service = new TeacherService();

        // WinAPI: TextBox "placeholder" (Cue Banner) for .NET Framework
        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        private static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wParam, string lParam);

        private const int EM_SETCUEBANNER = 0x1501;

        public frmTeachers()
        {
            Text = "Teachers";
            BackColor = Theme.Background;
            Size = new Size(900, 600);

            // ErrorProvider setup
            _errors = new ErrorProvider
            {
                ContainerControl = this
            };

            // NOTE: .NET Framework 4.8 TextBox does NOT have PlaceholderText
            _txtName = new TextBox { Dock = DockStyle.Top };
            _txtEmployeeNo = new TextBox { Dock = DockStyle.Top };

            var btnSave = new Button
            {
                Text = "Save",
                BackColor = Theme.Accent,
                ForeColor = Theme.TextPrimary,
                Height = 36,
                Dock = DockStyle.Top
            };

            UiEffects.ApplyHover(btnSave);
            btnSave.Click += (s, e) => SaveTeacher();

            var panel = new Panel
            {
                Dock = DockStyle.Left,
                Width = 260,
                BackColor = Theme.Panel,
                Padding = new Padding(12)
            };

            panel.Controls.Add(btnSave);
            panel.Controls.Add(_txtEmployeeNo);
            panel.Controls.Add(_txtName);

            Controls.Add(panel);

            // Apply placeholders AFTER controls have handles created.
            // Shown event ensures handle exists.
            Shown += (s, e) =>
            {
                SetPlaceholder(_txtName, "Teacher Name");
                SetPlaceholder(_txtEmployeeNo, "Employee No");
            };
        }

        private void SetPlaceholder(TextBox textBox, string placeholder)
        {
            if (textBox == null) return;

            // wParam = 1 => show cue banner even when focused (optional, nice UX)
            // If you don't want it on focus, set wParam = IntPtr.Zero
            SendMessage(textBox.Handle, EM_SETCUEBANNER, (IntPtr)1, placeholder);
        }

        private void SaveTeacher()
        {
            _errors.Clear();

            if (string.IsNullOrWhiteSpace(_txtName.Text))
            {
                _errors.SetError(_txtName, "Name is required.");
                return;
            }

            if (string.IsNullOrWhiteSpace(_txtEmployeeNo.Text))
            {
                _errors.SetError(_txtEmployeeNo, "Employee No is required.");
                return;
            }

            // (Optional) Here you can call your service to save teacher
            // Example (depends on your TeacherService API):
            // _service.Save(new Teacher { Name = _txtName.Text.Trim(), EmployeeNo = _txtEmployeeNo.Text.Trim() });
        }
    }
}