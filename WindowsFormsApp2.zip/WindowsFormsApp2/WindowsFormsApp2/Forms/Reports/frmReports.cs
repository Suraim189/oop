using System;
using System.Data;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace EduNova.WinForms
{
    public class frmReports : Form
    {
        private readonly TabControl _tabs;

        public frmReports()
        {
            Text = "Reports";
            BackColor = Theme.Background;
            Size = new System.Drawing.Size(1000, 700);

            _tabs = new TabControl { Dock = DockStyle.Fill };

            _tabs.TabPages.Add(CreateTab("Fee Due"));
            _tabs.TabPages.Add(CreateTab("Attendance"));
            _tabs.TabPages.Add(CreateTab("Exam Results"));
            _tabs.TabPages.Add(CreateTab("Substitutions"));

            Controls.Add(_tabs);
        }

        private TabPage CreateTab(string title)
        {
            var page = new TabPage(title);
            var grid = new DataGridView { Dock = DockStyle.Fill, BackgroundColor = Theme.Panel };
            var btnExport = new Button
            {
                Text = "Export CSV",
                BackColor = Theme.Accent,
                ForeColor = Theme.TextPrimary,
                Dock = DockStyle.Top,
                Height = 36
            };

            UiEffects.ApplyHover(btnExport);
            btnExport.Click += (s, e) => ExportToCsv(grid);

            page.Controls.Add(grid);
            page.Controls.Add(btnExport);
            return page;
        }

        private void ExportToCsv(DataGridView grid)
        {
            if (grid.DataSource == null)
            {
                return;
            }

            using (var dialog = new SaveFileDialog { Filter = "CSV Files (*.csv)|*.csv", FileName = "report.csv" })
            {
                if (dialog.ShowDialog() != DialogResult.OK)
                {
                    return;
                }

                var table = grid.DataSource as DataTable;
                if (table == null)
                {
                    return;
                }

                var sb = new StringBuilder();
                for (var i = 0; i < table.Columns.Count; i++)
                {
                    sb.Append(table.Columns[i].ColumnName);
                    if (i < table.Columns.Count - 1) sb.Append(",");
                }
                sb.AppendLine();

                foreach (DataRow row in table.Rows)
                {
                    for (var i = 0; i < table.Columns.Count; i++)
                    {
                        var value = row[i]?.ToString()?.Replace("\"", "\"\"");
                        sb.Append("\"" + value + "\"");
                        if (i < table.Columns.Count - 1) sb.Append(",");
                    }
                    sb.AppendLine();
                }

                File.WriteAllText(dialog.FileName, sb.ToString());
            }
        }
    }
}
