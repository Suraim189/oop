using System;
using System.Drawing;
using System.Windows.Forms;

namespace EduNova.WinForms
{
    public class frmAttendanceMarking : Form
    {
        public frmAttendanceMarking()
        {
            Text = "Attendance Marking";
            BackColor = Theme.Background;
            Size = new Size(900, 600);

            var datePicker = new DateTimePicker { Dock = DockStyle.Top };
            var grid = new DataGridView { Dock = DockStyle.Fill, BackgroundColor = Theme.Panel };

            var btnSave = new Button
            {
                Text = "Save Attendance",
                BackColor = Theme.Accent,
                ForeColor = Theme.TextPrimary,
                Dock = DockStyle.Bottom,
                Height = 36
            };
            UiEffects.ApplyHover(btnSave);

            Controls.Add(grid);
            Controls.Add(btnSave);
            Controls.Add(datePicker);
        }
    }
}
