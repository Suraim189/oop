﻿using System.Drawing;
using System.Windows.Forms;
using EduNova.WinForms.UIContracts;

namespace EduNova.WinForms.Forms.Common
{
    public class BaseEditDialog : BaseForm, IValidatableForm
    {
        protected Button OkButton;
        protected new Button CancelButton;
        protected ErrorProvider ErrorProvider;

        public BaseEditDialog()
        {
            ErrorProvider = new ErrorProvider();
            OkButton = new Button
            {
                Text = "OK",
                BackColor = Theme.Accent,
                ForeColor = Theme.TextPrimary,
                Width = 80,
                Height = 28
            };
            CancelButton = new Button
            {
                Text = "Cancel",
                BackColor = Theme.Panel,
                ForeColor = Theme.TextPrimary,
                Width = 80,
                Height = 28
            };
            UiEffects.ApplyHover(OkButton);

            var panel = new FlowLayoutPanel
            {
                Dock = DockStyle.Bottom,
                Height = 40,
                FlowDirection = FlowDirection.RightToLeft
            };
            panel.Controls.Add(CancelButton);
            panel.Controls.Add(OkButton);
            Controls.Add(panel);

            OkButton.Click += (s, e) =>
            {
                if (ValidateForm(out var message))
                {
                    DialogResult = DialogResult.OK;
                }
                else
                {
                    MessageBox.Show(message, Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            };

            CancelButton.Click += (s, e) => DialogResult = DialogResult.Cancel;
        }

        public virtual bool ValidateForm(out string message)
        {
            message = string.Empty;
            return true;
        }
    }
}
