﻿using System.Drawing;
using System.Windows.Forms;
using EduNova.WinForms.UIContracts;
using System.Runtime.InteropServices;

namespace EduNova.WinForms.Forms.Common
{
    public class BaseCrudListForm : BaseForm, IRefreshable
    {
        protected DataGridView Grid;
        protected TextBox SearchBox;
        protected Button AddButton;
        protected Button EditButton;
        protected Button DeleteButton;

        public BaseCrudListForm()
        {
            Grid = new DataGridView { Dock = DockStyle.Fill, BackgroundColor = Theme.Panel };
            SearchBox = new TextBox { Dock = DockStyle.Top };
            
            AddButton = CreateButton("Add");
            EditButton = CreateButton("Edit");
            DeleteButton = CreateButton("Delete");

            var toolbar = new FlowLayoutPanel
            {
                Dock = DockStyle.Top,
                Height = 40,
                BackColor = Theme.Panel
            };

            toolbar.Controls.Add(AddButton);
            toolbar.Controls.Add(EditButton);
            toolbar.Controls.Add(DeleteButton);

            Controls.Add(Grid);
            Controls.Add(toolbar);
            Controls.Add(SearchBox);

            AddButton.Click += (s, e) => OnAdd();
            EditButton.Click += (s, e) => OnEdit();
            DeleteButton.Click += (s, e) => OnDelete();
            SearchBox.TextChanged += (s, e) => ApplyFilter();
        }

        public virtual void RefreshData()
        {
            LoadGrid();
        }

        protected virtual void LoadGrid() { }
        protected virtual void ApplyFilter() { }
        protected virtual void OnAdd() { }
        protected virtual void OnEdit() { }
        protected virtual void OnDelete() { }

        private static Button CreateButton(string text)
        {
            var button = new Button
            {
                Text = text,
                BackColor = Theme.Accent,
                ForeColor = Theme.TextPrimary,
                Width = 80,
                Height = 28,
                Margin = new Padding(6, 6, 0, 6)
            };
            UiEffects.ApplyHover(button);
            return button;
        }
    }
}
