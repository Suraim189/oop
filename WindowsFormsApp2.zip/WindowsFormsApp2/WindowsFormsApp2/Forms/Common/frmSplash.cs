﻿using System;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Windows.Forms;

namespace EduNova.WinForms
{
    public class frmSplash : Form
    {
        private readonly Timer _timer;

        public frmSplash()
        {
            Text = "EduNova";
            Size = new Size(500, 350);
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Theme.Background;

            var layout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                RowCount = 2,
                BackColor = Theme.Background
            };
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 70F));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 30F));

            // Logo
            var logoPanel = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Theme.Background
            };

            var logoPath = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "EduNovaLogo.jpg");
            if (File.Exists(logoPath))
            {
                try
                {
                    var originalImg = Image.FromFile(logoPath);
                    var logoBox = new PictureBox
                    {
                        Size = new Size(160, 160),
                        SizeMode = PictureBoxSizeMode.Zoom,
                        Image = originalImg,
                        BackColor = Theme.Background
                    };
                    logoBox.Location = new Point((logoPanel.Width - logoBox.Width) / 2, 20);
                    logoPanel.Controls.Add(logoBox);
                    logoPanel.Resize += (s, e) =>
                    {
                        logoBox.Location = new Point((logoPanel.Width - logoBox.Width) / 2, 20);
                    };
                }
                catch { /* logo won't show, app still works */ }
            }

            // Title label
            var title = new Label
            {
                Text = "EduNova",
                ForeColor = Theme.TextPrimary,
                Font = new Font("Segoe UI", 22, FontStyle.Bold),
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleCenter
            };

            layout.Controls.Add(logoPanel, 0, 0);
            layout.Controls.Add(title, 0, 1);

            Controls.Add(layout);

            _timer = new Timer { Interval = 2500 };
            _timer.Tick += (s, e) =>
            {
                _timer.Stop();
                Hide();
                new frmLogin().Show();
            };
            _timer.Start();
        }
    }
}
