﻿using System;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Windows.Forms;
using EduNova.WinForms.UIContracts;

namespace EduNova.WinForms
{
    public class frmLogin : Form
    {
        private TextBox txtUsername;
        private TextBox txtPassword;

        public frmLogin()
        {
            Text = "EduNova - Login";
            Size = new Size(440, 460);
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Theme.Background;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;

            var panel = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Theme.Background,
                Padding = new Padding(30)
            };

            // Logo at top
            var logoPanel = new Panel
            {
                Height = 100,
                Dock = DockStyle.Top,
                BackColor = Theme.Background
            };

            var logoPath = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "EduNovaLogo.jpg");
            if (File.Exists(logoPath))
            {
                try
                {
                    var logoBox = new PictureBox
                    {
                        Size = new Size(80, 80),
                        SizeMode = PictureBoxSizeMode.Zoom,
                        Image = Image.FromFile(logoPath),
                        BackColor = Theme.Background
                    };
                    logoBox.Location = new Point((logoPanel.Width - logoBox.Width) / 2, 10);
                    logoPanel.Controls.Add(logoBox);
                    logoPanel.Resize += (s, e) =>
                    {
                        logoBox.Left = (logoPanel.Width - logoBox.Width) / 2;
                    };
                }
                catch { }
            }

            var title = new Label
            {
                Text = "EduNova",
                Font = new Font("Segoe UI", 18, FontStyle.Bold),
                ForeColor = Theme.TextPrimary,
                Dock = DockStyle.Top,
                Height = 40,
                TextAlign = ContentAlignment.MiddleCenter
            };

            var lblUser = new Label
            {
                Text = "Username",
                ForeColor = Theme.TextSecondary,
                Dock = DockStyle.Top,
                Height = 20
            };

            txtUsername = new TextBox
            {
                Dock = DockStyle.Top,
                Height = 28,
                BackColor = Theme.Panel,
                ForeColor = Theme.TextPrimary,
                BorderStyle = BorderStyle.FixedSingle
            };

            var lblPass = new Label
            {
                Text = "Password",
                ForeColor = Theme.TextSecondary,
                Dock = DockStyle.Top,
                Height = 20,
                Margin = new Padding(0, 10, 0, 0)
            };

            txtPassword = new TextBox
            {
                Dock = DockStyle.Top,
                Height = 28,
                BackColor = Theme.Panel,
                ForeColor = Theme.TextPrimary,
                BorderStyle = BorderStyle.FixedSingle,
                UseSystemPasswordChar = true
            };

            var btnLogin = new Button
            {
                Text = "Login",
                BackColor = Theme.Accent,
                ForeColor = Theme.TextPrimary,
                Dock = DockStyle.Top,
                Height = 40,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                Margin = new Padding(0, 20, 0, 0)
            };
            btnLogin.FlatAppearance.BorderSize = 0;
            UiEffects.ApplyHover(btnLogin);
            btnLogin.Click += BtnLogin_Click;

            // Add controls in order
            panel.Controls.Add(btnLogin);
            panel.Controls.Add(txtPassword);
            panel.Controls.Add(lblPass);
            panel.Controls.Add(txtUsername);
            panel.Controls.Add(lblUser);
            panel.Controls.Add(title);
            panel.Controls.Add(logoPanel);

            Controls.Add(panel);
        }

        private void BtnLogin_Click(object sender, EventArgs e)
        {
            var authService = new EduNova.Services.AuthService();
            var result = authService.Login(txtUsername.Text, txtPassword.Text);

            if (result.IsSuccess)
            {
                UserContext.CurrentUserId = result.UserId;
                UserContext.CurrentUserName = result.DisplayName;
                UserContext.CurrentRoleId = result.RoleId;

                Hide();
                var main = new frmMain();
                main.FormClosed += (s, args) => Close();
                main.Show();
            }
            else
            {
                MessageBox.Show(result.Message, "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
