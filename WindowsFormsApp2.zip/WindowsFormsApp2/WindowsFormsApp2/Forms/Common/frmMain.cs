﻿using System;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Windows.Forms;

namespace EduNova.WinForms
{
    public class frmMain : Form
    {
        private readonly Label _clockLabel;
        private readonly Timer _clockTimer;
        private readonly Panel _contentPanel;

        public frmMain()
        {
            Text = "EduNova - School Management System";
            WindowState = FormWindowState.Maximized;
            BackColor = Theme.Background;

            // Top bar
            var topBar = new Panel
            {
                Dock = DockStyle.Top,
                Height = 50,
                BackColor = Theme.Panel
            };

            // Small logo in topbar
            var logoPath = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "EduNovaLogo.jpg");
            if (File.Exists(logoPath))
            {
                try
                {
                    var smallLogo = new PictureBox
                    {
                        Size = new Size(36, 36),
                        SizeMode = PictureBoxSizeMode.Zoom,
                        Image = Image.FromFile(logoPath),
                        BackColor = Theme.Panel,
                        Location = new Point(8, 7)
                    };
                    topBar.Controls.Add(smallLogo);
                }
                catch { }
            }

            var titleLabel = new Label
            {
                Text = "EduNova",
                ForeColor = Theme.TextPrimary,
                Font = new Font("Segoe UI", 14, FontStyle.Bold),
                AutoSize = true,
                Location = new Point(50, 12)
            };
            topBar.Controls.Add(titleLabel);

            _clockLabel = new Label
            {
                Dock = DockStyle.Right,
                Width = 150,
                ForeColor = Theme.TextPrimary,
                TextAlign = ContentAlignment.MiddleRight,
                Font = new Font("Segoe UI", 10),
                Margin = new Padding(0, 0, 10, 0)
            };
            topBar.Controls.Add(_clockLabel);

            // Sidebar
            var sidebar = new Panel
            {
                Dock = DockStyle.Left,
                Width = 220,
                BackColor = Theme.Panel
            };

            // Navigation buttons
            string[] modules = {
                "Students", "Teachers", "Classes", "Subjects",
                "Timetable", "Attendance", "Exams", "Fees",
                "Library", "Reports", "Admin"
            };

            int yOffset = 10;
            foreach (var mod in modules)
            {
                var btn = new Button
                {
                    Text = mod,
                    Dock = DockStyle.Top,
                    Height = 38,
                    FlatStyle = FlatStyle.Flat,
                    BackColor = Theme.Panel,
                    ForeColor = Theme.TextSecondary,
                    Font = new Font("Segoe UI", 10),
                    TextAlign = ContentAlignment.MiddleLeft,
                    Padding = new Padding(15, 0, 0, 0),
                    Margin = new Padding(0, 1, 0, 1),
                    Tag = mod
                };
                btn.FlatAppearance.BorderSize = 0;
                btn.MouseEnter += (s, e) => btn.BackColor = Theme.Accent;
                btn.MouseLeave += (s, e) => btn.BackColor = Theme.Panel;
                btn.Click += NavButton_Click;
                sidebar.Controls.Add(btn);
                yOffset += 40;
            }

            // Content panel
            _contentPanel = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Theme.Background
            };

            Controls.Add(_contentPanel);
            Controls.Add(topBar);
            Controls.Add(sidebar);

            _clockTimer = new Timer { Interval = 1000 };
            _clockTimer.Tick += (s, e) => _clockLabel.Text = DateTime.Now.ToString("HH:mm:ss");
            _clockTimer.Start();
        }

        private void NavButton_Click(object sender, EventArgs e)
        {
            var btn = (Button)sender;
            var module = btn.Tag.ToString();
            OpenModule(module);
        }

        private void OpenModule(string module)
        {
            _contentPanel.Controls.Clear();
            Form moduleForm = null;

            try
            {
                switch (module)
                {
                    case "Students": moduleForm = new frmStudents(); break;
                    case "Teachers": moduleForm = new frmTeachers(); break;
                    case "Classes": moduleForm = new frmClassSections(); break;
                    case "Subjects": moduleForm = new frmSubjects(); break;
                    case "Timetable": moduleForm = new frmTimetableEditor(); break;
                    case "Attendance": moduleForm = new frmAttendanceMarking(); break;
                    case "Exams": moduleForm = new frmExams(); break;
                    case "Fees": moduleForm = new frmFeePayment(); break;
                    case "Library": moduleForm = new frmLibraryBooks(); break;
                    case "Reports": moduleForm = new frmReports(); break;
                    case "Admin": moduleForm = new frmUsers(); break;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Could not open {module}: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (moduleForm != null)
            {
                moduleForm.TopLevel = false;
                moduleForm.Dock = DockStyle.Fill;
                moduleForm.FormBorderStyle = FormBorderStyle.None;
                _contentPanel.Controls.Add(moduleForm);
                moduleForm.Show();
            }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            _clockTimer?.Stop();
            base.OnFormClosing(e);
        }
    }
}
