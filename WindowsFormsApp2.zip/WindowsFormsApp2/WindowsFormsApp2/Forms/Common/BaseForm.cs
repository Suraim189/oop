﻿using System.Drawing;
using System.Windows.Forms;
using EduNova.WinForms.UIContracts;

namespace EduNova.WinForms.Forms.Common
{
    public class BaseForm : Form, IThemeable
    {
        private readonly Panel _loadingOverlay;

        public BaseForm()
        {
            Font = new Font("Segoe UI", 9F);
            BackColor = Theme.Background;
            ForeColor = Theme.TextPrimary;
            StartPosition = FormStartPosition.CenterScreen;

            _loadingOverlay = new Panel
            {
                BackColor = Color.FromArgb(160, 0, 0, 0),
                Dock = DockStyle.Fill,
                Visible = false
            };
            Controls.Add(_loadingOverlay);
        }

        public virtual void ApplyTheme()
        {
            BackColor = Theme.Background;
            ForeColor = Theme.TextPrimary;
        }

        protected void ShowToast(string message)
        {
            MessageBox.Show(message, Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        protected void SetLoading(bool isLoading)
        {
            _loadingOverlay.Visible = isLoading;
            _loadingOverlay.BringToFront();
        }
    }
}
