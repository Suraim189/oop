using System.Collections.Generic;
using EduNova.Data.Repositories;
using EduNova.Domain.Entities;

namespace EduNova.Services
{
    public class StudentService
    {
        private readonly StudentRepository _repository = new StudentRepository();

        public void AddStudent(Student student)
        {
            var errors = student.Validate();
            if (errors.Count > 0)
            {
                return;
            }

            _repository.Add(student);
        }

        public void UpdateStudent(Student student)
        {
            var errors = student.Validate();
            if (errors.Count > 0)
            {
                return;
            }

            _repository.Update(student);
        }

        public void DeleteStudent(int id)
        {
            _repository.Delete(id);
        }

        public Student GetStudent(int id)
        {
            return _repository.GetById(id);
        }

        public List<Student> GetAllStudents()
        {
            return _repository.GetAll();
        }
    }
}
