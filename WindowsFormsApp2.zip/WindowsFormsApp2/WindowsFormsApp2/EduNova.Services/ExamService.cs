using System.Data;
using EduNova.Data.Repositories;

namespace EduNova.Services
{
    public class ExamService
    {
        private readonly ExamRepository _repository = new ExamRepository();

        public void CreateExam(int examTypeId, int classSectionId, int subjectId, System.DateTime examDate, decimal totalMarks)
        {
            _repository.CreateExam(examTypeId, classSectionId, subjectId, examDate, totalMarks);
        }

        public void SaveMarks(int examId, int studentId, decimal obtainedMarks)
        {
            _repository.SaveMarks(examId, studentId, obtainedMarks);
        }

        public DataTable GetExamResultReport()
        {
            return _repository.GetExamResultReport();
        }
    }
}
