using System;
using EduNova.Data.Repositories;

namespace EduNova.Services
{
    public class AttendanceService
    {
        private readonly AttendanceRepository _repository = new AttendanceRepository();

        public void SaveAttendance(int studentId, DateTime date, string status, int markedByUserId)
        {
            _repository.SaveAttendance(studentId, date, status, markedByUserId);
        }
    }
}
