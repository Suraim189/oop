using System.Data;
using EduNova.Data.Repositories;
using EduNova.Domain.DTOs;

namespace EduNova.Services
{
    public class AuthService
    {
        private readonly AdminRepository _adminRepository = new AdminRepository();

        public LoginResultDTO Login(string username, string password)
        {
            var table = _adminRepository.Login(username, password);
            if (table.Rows.Count == 0)
            {
                return new LoginResultDTO { IsSuccess = false, Message = "Invalid credentials." };
            }

            var row = table.Rows[0];
            return new LoginResultDTO
            {
                UserId = (int)row["UserId"],
                DisplayName = row["DisplayName"].ToString(),
                RoleId = (int)row["RoleId"],
                IsSuccess = true
            };
        }

        public DataTable GetPermissions(int userId)
        {
            return _adminRepository.GetPermissions(userId);
        }
    }
}
