using System;
using System.Data;
using EduNova.Data.Repositories;

namespace EduNova.Services
{
    public class LeaveService
    {
        private readonly LeaveRepository _repository = new LeaveRepository();

        public DataTable RequestLeave(int teacherId, DateTime leaveDate, string reason)
        {
            return _repository.RequestLeave(teacherId, leaveDate, reason);
        }
    }
}
