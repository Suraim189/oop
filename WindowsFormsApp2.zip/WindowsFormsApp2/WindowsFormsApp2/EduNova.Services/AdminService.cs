using System.Data;
using EduNova.Data.Repositories;

namespace EduNova.Services
{
    public class AdminService
    {
        private readonly AdminRepository _repository = new AdminRepository();

        public DataTable Login(string username, string password)
        {
            return _repository.Login(username, password);
        }

        public DataTable GetPermissions(int userId)
        {
            return _repository.GetPermissions(userId);
        }
    }
}
