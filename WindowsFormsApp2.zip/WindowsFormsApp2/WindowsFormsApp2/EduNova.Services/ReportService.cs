using System.Data;
using EduNova.Data.Repositories;

namespace EduNova.Services
{
    public class ReportService
    {
        private readonly ReportRepository _repository = new ReportRepository();

        public DataTable GetDashboardCounts()
        {
            return _repository.GetDashboardCounts();
        }

        public DataTable GetFeeDueReport()
        {
            return _repository.GetFeeDueReport();
        }

        public DataTable GetExamResultReport()
        {
            return _repository.GetExamResultReport();
        }
    }
}
