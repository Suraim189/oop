using System.Data;
using EduNova.Data.Repositories;

namespace EduNova.Services
{
    public class FeeService
    {
        private readonly FeeRepository _repository = new FeeRepository();

        public void GenerateFeeVouchers(int month, int year)
        {
            _repository.GenerateFeeVouchers(month, year);
        }

        public void PayVoucher(int voucherId, decimal paidAmount, System.DateTime paidOn, string method, int receivedByUserId)
        {
            _repository.PayVoucher(voucherId, paidAmount, paidOn, method, receivedByUserId);
        }

        public DataTable GetFeeDueStudents()
        {
            return _repository.GetFeeDueStudents();
        }
    }
}
