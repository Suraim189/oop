using System.Collections.Generic;
using EduNova.Data.Repositories;
using EduNova.Domain.Entities;

namespace EduNova.Services
{
    public class TeacherService
    {
        private readonly TeacherRepository _repository = new TeacherRepository();

        public void AddTeacher(Teacher teacher)
        {
            var errors = teacher.Validate();
            if (errors.Count > 0)
            {
                return;
            }

            _repository.Add(teacher);
        }

        public void UpdateTeacher(Teacher teacher)
        {
            var errors = teacher.Validate();
            if (errors.Count > 0)
            {
                return;
            }

            _repository.Update(teacher);
        }

        public void DeleteTeacher(int id)
        {
            _repository.Delete(id);
        }

        public Teacher GetTeacher(int id)
        {
            return _repository.GetById(id);
        }

        public List<Teacher> GetAllTeachers()
        {
            return _repository.GetAll();
        }
    }
}
