using EduNova.Data.Repositories;

namespace EduNova.Services
{
    public class LibraryService
    {
        private readonly LibraryRepository _repository = new LibraryRepository();

        public void IssueBook(int copyId, int studentId, System.DateTime issuedOn, System.DateTime dueOn)
        {
            _repository.IssueBook(copyId, studentId, issuedOn, dueOn);
        }

        public void ReturnBook(int issueId, System.DateTime returnedOn, decimal fineAmount)
        {
            _repository.ReturnBook(issueId, returnedOn, fineAmount);
        }
    }
}
