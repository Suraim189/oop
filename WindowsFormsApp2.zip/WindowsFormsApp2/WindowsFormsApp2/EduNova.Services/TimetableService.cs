using EduNova.Data.Repositories;
using EduNova.Domain.Entities;

namespace EduNova.Services
{
    public class TimetableService
    {
        private readonly TimetableRepository _repository = new TimetableRepository();

        public void AddEntry(TimetableEntry entry)
        {
            var errors = entry.Validate();
            if (errors.Count > 0)
            {
                return;
            }

            _repository.SaveEntry(entry);
        }
    }
}
