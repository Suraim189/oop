using System;
using EduNova.Data.Repositories;

namespace EduNova.Services
{
    public class SubstitutionService
    {
        private readonly SubstitutionRepository _repository = new SubstitutionRepository();

        public int FindSubstitute(int subjectId, int domainId, int timeSlotId, int dayOfWeek)
        {
            return _repository.FindSubstitute(subjectId, domainId, timeSlotId, dayOfWeek);
        }

        public void AssignSubstitution(int entryId, DateTime date, int originalTeacherId, int substituteTeacherId, string reason)
        {
            _repository.AssignSubstitution(entryId, date, originalTeacherId, substituteTeacherId, reason);
        }
    }
}
