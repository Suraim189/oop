using System.Data;
using EduNova.Data.Repositories;

namespace EduNova.Services
{
    public class NotificationService
    {
        private readonly NotificationRepository _repository = new NotificationRepository();

        public void CreateNotification(int toUserId, string title, string message, string type)
        {
            _repository.CreateNotification(toUserId, title, message, type);
        }

        public DataTable GetUnreadNotifications(int toUserId)
        {
            return _repository.GetUnreadNotifications(toUserId);
        }
    }
}
