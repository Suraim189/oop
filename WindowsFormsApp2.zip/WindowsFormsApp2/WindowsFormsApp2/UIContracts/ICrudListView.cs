using System.Collections.Generic;

namespace EduNova.WinForms.UIContracts
{
    public interface ICrudListView<TGridDto>
    {
        void BindGrid(List<TGridDto> rows);
        void ShowMessage(string msg);
        string SearchText { get; }
    }
}
