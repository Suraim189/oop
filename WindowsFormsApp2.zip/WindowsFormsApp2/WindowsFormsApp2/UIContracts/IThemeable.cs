namespace EduNova.WinForms.UIContracts
{
    public interface IThemeable
    {
        void ApplyTheme();
    }
}
