namespace EduNova.WinForms.UIContracts
{
    public interface IValidatableForm
    {
        bool ValidateForm(out string message);
    }
}
