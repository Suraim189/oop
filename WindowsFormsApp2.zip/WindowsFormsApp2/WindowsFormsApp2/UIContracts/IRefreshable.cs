namespace EduNova.WinForms.UIContracts
{
    public interface IRefreshable
    {
        void RefreshData();
    }
}
