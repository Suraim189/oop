namespace EduNova.WinForms.UIContracts
{
    public interface IEditView<TEditDto>
    {
        void LoadData(TEditDto dto);
        TEditDto CollectData();
        void ShowValidationError(string msg);
    }
}
