namespace EduNova.WinForms.UIContracts
{
    public interface IRoleAware
    {
        void ApplyPermissions();
    }
}
