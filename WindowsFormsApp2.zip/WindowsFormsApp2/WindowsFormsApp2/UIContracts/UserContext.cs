using System.Collections.Generic;

namespace EduNova.WinForms.UIContracts
{
    public static class UserContext
    {
        public static int CurrentUserId { get; set; }
        public static string CurrentUserName { get; set; }
        public static int CurrentRoleId { get; set; }
        public static string Role { get; set; }
        public static List<string> Permissions { get; set; } = new List<string>();
    }
}
