using System;
using System.Data;
using EduNova.Domain.Entities;
using EduNova.Domain.Enums;

namespace EduNova.Data.Mappers
{
    public static class StudentMapper
    {
        public static Student MapFromDataRow(DataRow r)
        {
            return new Student
            {
                StudentId = Convert.ToInt32(r["StudentId"]),
                PersonId = Convert.ToInt32(r["PersonId"]),
                FirstName = r["FirstName"].ToString(),
                LastName = r["LastName"].ToString(),
                AdmissionNo = r["AdmissionNo"].ToString(),
                AdmissionDate = Convert.ToDateTime(r["AdmissionDate"]),
                DateOfBirth = r["DateOfBirth"] as DateTime?,
                Gender = (Gender)Convert.ToInt32(r["Gender"]),
                Phone = r["Phone"].ToString(),
                Email = r["Email"].ToString(),
                Address = r["Address"].ToString(),
                IsActive = Convert.ToBoolean(r["IsActive"]),
                Profile = new StudentProfile
                {
                    StudentId = Convert.ToInt32(r["StudentId"]),
                    BloodGroup = r["BloodGroup"].ToString(),
                    MedicalConditions = r["MedicalConditions"].ToString(),
                    PreviousSchool = r["PreviousSchool"].ToString()
                },
                Guardian = new Guardian
                {
                    StudentId = Convert.ToInt32(r["StudentId"]),
                    Name = r["GuardianName"].ToString(),
                    Relation = r["GuardianRelation"].ToString(),
                    Phone = r["GuardianPhone"].ToString(),
                    Occupation = r["GuardianOccupation"].ToString(),
                    CNIC = r["GuardianCNIC"].ToString()
                }
            };
        }
    }
}
