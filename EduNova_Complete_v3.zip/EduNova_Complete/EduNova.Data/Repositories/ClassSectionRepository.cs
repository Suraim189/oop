using System.Data;

namespace EduNova.Data.Repositories
{
    public class ClassSectionRepository
    {
        public static DataTable GetAll()
        {
            return SqlHelper.ExecuteDataTable("sp_ClassSection_GetAll");
        }

        public static int InsertClass(string className, string description)
        {
            return SqlHelper.ExecuteNonQuery("sp_GradeClass_Insert",
                SqlHelper.Param("@ClassName", className),
                SqlHelper.Param("@Description", description));
        }

        public static int UpdateClass(int gradeClassId, string className, string description)
        {
            return SqlHelper.ExecuteNonQuery("sp_GradeClass_Update",
                SqlHelper.Param("@GradeClassId", gradeClassId),
                SqlHelper.Param("@ClassName", className),
                SqlHelper.Param("@Description", description));
        }

        public static int DeleteClass(int gradeClassId)
        {
            return SqlHelper.ExecuteNonQuery("sp_GradeClass_Delete",
                SqlHelper.Param("@GradeClassId", gradeClassId));
        }

        public static int InsertSection(int gradeClassId, string sectionName, int? classTeacherId, int maxStudents)
        {
            return SqlHelper.ExecuteNonQuery("sp_ClassSection_Insert",
                SqlHelper.Param("@GradeClassId", gradeClassId),
                SqlHelper.Param("@SectionName", sectionName),
                SqlHelper.Param("@ClassTeacherId", (object)classTeacherId ?? System.DBNull.Value),
                SqlHelper.Param("@MaxStudents", maxStudents));
        }

        public static int DeleteSection(int classSectionId)
        {
            return SqlHelper.ExecuteNonQuery("sp_ClassSection_Delete",
                SqlHelper.Param("@ClassSectionId", classSectionId));
        }
    }
}
