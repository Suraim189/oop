using System.Data;
using System.Data.SqlClient;
using EduNova.Data.Mappers;
using EduNova.Domain.Entities;

namespace EduNova.Data.Repositories
{
    public class StudentRepository
    {
        public static DataTable GetAll()
        {
            return SqlHelper.ExecuteDataTable("sp_Student_Get",
                SqlHelper.Param("@StudentId", DBNull.Value));
        }

        public static DataTable Search(string keyword)
        {
            return SqlHelper.ExecuteDataTable("sp_Student_Search",
                SqlHelper.Param("@Keyword", keyword));
        }

        public static DataRow GetById(int studentId)
        {
            var dt = SqlHelper.ExecuteDataTable("sp_Student_Get",
                SqlHelper.Param("@StudentId", studentId));
            return dt.Rows.Count > 0 ? dt.Rows[0] : null;
        }

        public static int Insert(Student s)
        {
            return SqlHelper.ExecuteNonQuery("sp_Student_Insert",
                SqlHelper.Param("@FirstName", s.FirstName),
                SqlHelper.Param("@LastName", s.LastName),
                SqlHelper.Param("@DateOfBirth", (object)s.DateOfBirth ?? System.DBNull.Value),
                SqlHelper.Param("@Gender", (int)s.Gender),
                SqlHelper.Param("@Phone", s.Phone),
                SqlHelper.Param("@Email", s.Email),
                SqlHelper.Param("@Address", s.Address),
                SqlHelper.Param("@AdmissionNo", s.AdmissionNo),
                SqlHelper.Param("@AdmissionDate", s.AdmissionDate),
                SqlHelper.Param("@BloodGroup", s.Profile?.BloodGroup),
                SqlHelper.Param("@MedicalConditions", s.Profile?.MedicalConditions),
                SqlHelper.Param("@PreviousSchool", s.Profile?.PreviousSchool),
                SqlHelper.Param("@GuardianName", s.Guardian?.Name),
                SqlHelper.Param("@GuardianRelation", s.Guardian?.Relation),
                SqlHelper.Param("@GuardianPhone", s.Guardian?.Phone),
                SqlHelper.Param("@GuardianOccupation", s.Guardian?.Occupation),
                SqlHelper.Param("@GuardianCNIC", s.Guardian?.CNIC),
                SqlHelper.Param("@ClassSectionId", s.Enrollments?.Count > 0 ? s.Enrollments[0].ClassSectionId : 0));
        }

        public static int Update(Student s)
        {
            return SqlHelper.ExecuteNonQuery("sp_Student_Update",
                SqlHelper.Param("@StudentId", s.StudentId),
                SqlHelper.Param("@FirstName", s.FirstName),
                SqlHelper.Param("@LastName", s.LastName),
                SqlHelper.Param("@DateOfBirth", (object)s.DateOfBirth ?? System.DBNull.Value),
                SqlHelper.Param("@Gender", (int)s.Gender),
                SqlHelper.Param("@Phone", s.Phone),
                SqlHelper.Param("@Email", s.Email),
                SqlHelper.Param("@Address", s.Address),
                SqlHelper.Param("@AdmissionNo", s.AdmissionNo),
                SqlHelper.Param("@AdmissionDate", s.AdmissionDate),
                SqlHelper.Param("@IsActive", s.IsActive),
                SqlHelper.Param("@BloodGroup", s.Profile?.BloodGroup),
                SqlHelper.Param("@MedicalConditions", s.Profile?.MedicalConditions),
                SqlHelper.Param("@PreviousSchool", s.Profile?.PreviousSchool),
                SqlHelper.Param("@GuardianName", s.Guardian?.Name),
                SqlHelper.Param("@GuardianRelation", s.Guardian?.Relation),
                SqlHelper.Param("@GuardianPhone", s.Guardian?.Phone),
                SqlHelper.Param("@GuardianOccupation", s.Guardian?.Occupation),
                SqlHelper.Param("@GuardianCNIC", s.Guardian?.CNIC),
                SqlHelper.Param("@ClassSectionId", s.Enrollments?.Count > 0 ? s.Enrollments[0].ClassSectionId : 0));
        }

        public static int Delete(int studentId)
        {
            return SqlHelper.ExecuteNonQuery("sp_Student_Delete",
                SqlHelper.Param("@StudentId", studentId));
        }

        public static DataTable GetForClass(int classSectionId)
        {
            return SqlHelper.ExecuteDataTable("sp_GetStudentsForAttendance",
                SqlHelper.Param("@ClassSectionId", classSectionId));
        }
    }
}
