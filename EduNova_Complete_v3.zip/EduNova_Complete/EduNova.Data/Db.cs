using System.Configuration;
using System.Data.SqlClient;

namespace EduNova.Data
{
    public static class Db
    {
        public static string ConnectionString
        {
            get
            {
                return ConfigurationManager.ConnectionStrings["EduNovaDB"].ConnectionString;
            }
        }

        public static SqlConnection GetConnection()
        {
            return new SqlConnection(ConnectionString);
        }
    }
}
