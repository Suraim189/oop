namespace EduNova.Domain.Entities
{
    public class Section
    {
        public int SectionId { get; set; }
        public string SectionName { get; set; }
    }
}