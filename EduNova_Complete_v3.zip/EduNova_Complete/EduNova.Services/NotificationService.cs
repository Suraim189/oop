using System.Data;
using EduNova.Data.Repositories;

namespace EduNova.Services
{
    public class NotificationService
    {
        public int CreateNotification(string title, string message, int type, int? targetUserId)
            => NotificationRepository.CreateNotification(title, message, type, targetUserId);
        public DataTable GetUnread(int? userId) => NotificationRepository.GetUnread(userId);
        public int MarkAsRead(int id) => NotificationRepository.MarkAsRead(id);
    }
}
