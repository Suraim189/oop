using System;
using System.Data;
using System.Windows.Forms;
using EduNova.Services;
using EduNova.WinForms.Helpers;

namespace EduNova.WinForms.Forms.Fees
{
    public partial class frmVoucherGenerate : Form
    {
        private readonly FeeService _svc = new FeeService();
        private readonly ClassSectionService _csSvc = new ClassSectionService();
        private DataTable _vouchers;
        public frmVoucherGenerate() { InitializeComponent(); Load += frmVoucherGenerate_Load; Theme.StyleDataGridView(dgvMain); SetupGrid(); }
        private void SetupGrid()
        {
            dgvMain.Columns.Clear();
            dgvMain.Columns.Add(new DataGridViewTextBoxColumn { Name = "colStudent", HeaderText = "Student", Width = 140 });
            dgvMain.Columns.Add(new DataGridViewTextBoxColumn { Name = "colClass", HeaderText = "Class", Width = 100 });
            dgvMain.Columns.Add(new DataGridViewTextBoxColumn { Name = "colMonth", HeaderText = "Month", Width = 70 });
            dgvMain.Columns.Add(new DataGridViewTextBoxColumn { Name = "colYear", HeaderText = "Year", Width = 50 });
            dgvMain.Columns.Add(new DataGridViewTextBoxColumn { Name = "colAmount", HeaderText = "Amount", Width = 90 });
            dgvMain.Columns.Add(new DataGridViewTextBoxColumn { Name = "colDue", HeaderText = "Due Date", Width = 90 });
            dgvMain.Columns.Add(new DataGridViewTextBoxColumn { Name = "colStatus", HeaderText = "Status", Width = 70 });
        }
        private void frmVoucherGenerate_Load(object sender, EventArgs e) { try { var cl = _csSvc.GetAll(); cmbClassSection.DataSource = cl; cmbClassSection.DisplayMember = "DisplayName"; cmbClassSection.ValueMember = "ClassSectionId"; } catch { } }
        private void btnGenerate_Click(object sender, EventArgs e) { try { int? classId = cmbClassSection.SelectedIndex == 0 ? (int?)null : (int)cmbClassSection.SelectedValue; int count = _svc.GenerateVouchers(classId, cmbMonth.SelectedItem.ToString(), (int)numYear.Value); _vouchers = _svc.GetVouchers(); dgvMain.DataSource = _vouchers; lblCount.Text = $"Generated: {count} vouchers"; MessageBox.Show($"{count} vouchers generated!", "Success"); } catch (Exception ex) { MessageBox.Show("Error: " + ex.Message); } }

    }
}
