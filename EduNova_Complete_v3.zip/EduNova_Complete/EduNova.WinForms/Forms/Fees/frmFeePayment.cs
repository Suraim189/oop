using System;
using System.Data;
using System.Windows.Forms;
using EduNova.Services;
using EduNova.WinForms.Helpers;

namespace EduNova.WinForms.Forms.Fees
{
    public partial class frmFeePayment : Form
    {
        private readonly FeeService _svc = new FeeService();
        private DataTable _vouchers;

        public frmFeePayment()
        {
            InitializeComponent();
            Load += frmFeePayment_Load;
            Theme.StyleDataGridView(dgvPendingVouchers);
            SetupGrid();
        }

        private void SetupGrid()
        {
            dgvPendingVouchers.Columns.Clear();
            dgvPendingVouchers.Columns.Add(new DataGridViewTextBoxColumn { Name = "colMonth", HeaderText = "Month", Width = 80 });
            dgvPendingVouchers.Columns.Add(new DataGridViewTextBoxColumn { Name = "colYear", HeaderText = "Year", Width = 60 });
            dgvPendingVouchers.Columns.Add(new DataGridViewTextBoxColumn { Name = "colAmount", HeaderText = "Amount", Width = 110 });
            dgvPendingVouchers.Columns.Add(new DataGridViewTextBoxColumn { Name = "colDue", HeaderText = "Due Date", Width = 100 });
            dgvPendingVouchers.Columns.Add(new DataGridViewTextBoxColumn { Name = "colStatus", HeaderText = "Status", Width = 80 });
        }

        private void frmFeePayment_Load(object sender, EventArgs e) { }

        private void txtSearchStudent_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Enter) return;
            btnSearch_Click(sender, e);
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                _vouchers = _svc.SearchStudentVouchers(txtSearchStudent.Text.Trim());
                dgvPendingVouchers.DataSource = _vouchers;
            }
            catch (Exception ex) { MessageBox.Show("Error: " + ex.Message); }
        }

        private void dgvPendingVouchers_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvPendingVouchers.CurrentRow == null) return;
            var r = dgvPendingVouchers.CurrentRow;
            lblSelectedVoucher.Text = $"Student: {r.Cells["colStudent"]?.Value}
Month: {r.Cells["colMonth"].Value} {r.Cells["colYear"].Value}
Amount: {r.Cells["colAmount"].Value}";
            numPaidAmount.Value = Convert.ToDecimal(r.Cells["colAmount"].Value);
        }

        private void btnPayNow_Click(object sender, EventArgs e)
        {
            try
            {
                int voucherId = Convert.ToInt32(_vouchers.Rows[dgvPendingVouchers.CurrentRow.Index]["VoucherId"]);
                _svc.PayVoucher(voucherId, numPaidAmount.Value, cmbPaymentMethod.SelectedIndex + 1, AppState.CurrentUser?.UserId ?? 1);
                MessageBox.Show("Payment recorded!", "Success"); btnSearch_Click(sender, e);
            }
            catch (Exception ex) { MessageBox.Show("Error: " + ex.Message); }
        }
    }
}
