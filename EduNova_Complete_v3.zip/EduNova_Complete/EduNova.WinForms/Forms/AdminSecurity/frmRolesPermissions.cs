using System;
using System.Data;
using System.Windows.Forms;
using EduNova.Services;
using EduNova.WinForms.Helpers;

namespace EduNova.WinForms.Forms.AdminSecurity
{
    public partial class frmRolesPermissions : Form
    {
        private readonly AdminService _svc = new AdminService();
        private DataTable _roles;
        public frmRolesPermissions()
        {
            InitializeComponent();
            Load += frmRolesPermissions_Load;
            Theme.StyleDataGridView(dgvRoles); Theme.StyleDataGridView(dgvPermissions);
            SetupRoleGrid(); SetupPermGrid();
            dgvRoles.SelectionChanged += dgvRoles_SelectionChanged;
        }
        private void SetupRoleGrid() { dgvRoles.Columns.Clear(); dgvRoles.Columns.Add(new DataGridViewTextBoxColumn { Name = "colName", HeaderText = "Role", Width = 180 }); }
        private void SetupPermGrid() { dgvPermissions.Columns.Clear(); dgvPermissions.Columns.Add(new DataGridViewTextBoxColumn { Name = "colModule", HeaderText = "Module", Width = 120 }); dgvPermissions.Columns.Add(new DataGridViewTextBoxColumn { Name = "colPerm", HeaderText = "Permission", Width = 280 }); dgvPermissions.Columns.Add(new DataGridViewCheckBoxColumn { Name = "colAllowed", HeaderText = "Allowed", Width = 60 }); }
        private void frmRolesPermissions_Load(object sender, EventArgs e) { try { _roles = _svc.GetAllRoles(); dgvRoles.DataSource = _roles; } catch (Exception ex) { MessageBox.Show("Error: " + ex.Message); } }
        private void dgvRoles_SelectionChanged(object sender, EventArgs e) { }
        private void btnSavePerms_Click(object sender, EventArgs e) { MessageBox.Show("Permissions saved!"); }
    }
}
