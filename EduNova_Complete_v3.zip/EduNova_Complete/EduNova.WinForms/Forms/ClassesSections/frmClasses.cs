using System;
using System.Data;
using System.Windows.Forms;
using EduNova.Services;
using EduNova.WinForms.Helpers;

namespace EduNova.WinForms.Forms.ClassesSections
{
    public partial class frmClasses : Form
    {
        private readonly ClassSectionService _svc = new ClassSectionService();
        private DataTable _allClasses;
        public frmClasses() { InitializeComponent(); Load += frmClasses_Load; Theme.StyleDataGridView(dgvClasses); Theme.StyleDataGridView(dgvSections); }
        private void frmClasses_Load(object sender, EventArgs e) { LoadClasses(); SetupClassesGrid(); SetupSectionsGrid(); }
        private void SetupClassesGrid()
        {
            dgvClasses.Columns.Clear();
            dgvClasses.Columns.Add(new DataGridViewTextBoxColumn { Name = "colClassName", HeaderText = "Class Name", Width = 150 });
            dgvClasses.Columns.Add(new DataGridViewTextBoxColumn { Name = "colDesc", HeaderText = "Description", Width = 150 });
            dgvClasses.Columns.Add(new DataGridViewTextBoxColumn { Name = "colSectionCount", HeaderText = "Sections", Width = 80 });
        }
        private void SetupSectionsGrid()
        {
            dgvSections.Columns.Clear();
            dgvSections.Columns.Add(new DataGridViewTextBoxColumn { Name = "colSecName", HeaderText = "Section", Width = 100 });
            dgvSections.Columns.Add(new DataGridViewTextBoxColumn { Name = "colTeacher", HeaderText = "Class Teacher", Width = 150 });
            dgvSections.Columns.Add(new DataGridViewTextBoxColumn { Name = "colMax", HeaderText = "Max Students", Width = 100 });
            dgvSections.Columns.Add(new DataGridViewTextBoxColumn { Name = "colActive", HeaderText = "Active", Width = 60 });
        }
        private void LoadClasses() { _allClasses = _svc.GetAll(); dgvClasses.DataSource = _allClasses; }
        private void dgvClasses_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvClasses.CurrentRow == null) return;
            int gradeClassId = Convert.ToInt32(dgvClasses.CurrentRow.Cells["colClassName"].Value);
            var dv = _allClasses.DefaultView;
            dv.RowFilter = $"GradeClassId = {gradeClassId}";
            dgvSections.DataSource = dv.ToTable();
        }
        private void btnAddClass_Click(object sender, EventArgs e)
        {
            string name = Microsoft.VisualBasic.Interaction.InputBox("Class Name:", "Add Class", "");
            string desc = Microsoft.VisualBasic.Interaction.InputBox("Description:", "Add Class", "");
            if (!string.IsNullOrWhiteSpace(name)) { _svc.InsertClass(name, desc); LoadClasses(); }
        }
        private void btnEditClass_Click(object sender, EventArgs e) { }
        private void btnDeleteClass_Click(object sender, EventArgs e) { }
        private void btnAddSection_Click(object sender, EventArgs e) { }
        private void btnDeleteSection_Click(object sender, EventArgs e) { }
    }
}
