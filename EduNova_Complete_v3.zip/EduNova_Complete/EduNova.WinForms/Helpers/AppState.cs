using EduNova.Domain.DTOs;

namespace EduNova.WinForms.Helpers
{
    public static class AppState
    {
        public static LoginResultDTO CurrentUser { get; private set; }

        public static void SetUser(LoginResultDTO user)
        {
            CurrentUser = user;
        }

        public static void ClearUser()
        {
            CurrentUser = null;
        }

        public static bool IsLoggedIn => CurrentUser != null;

        public static bool HasPermission(string permissionCode)
        {
            return true;
        }
    }
}
