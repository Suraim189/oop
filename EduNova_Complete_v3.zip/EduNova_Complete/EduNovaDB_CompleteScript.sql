-- ============================================================
-- EduNovaDB Complete SQL Script
-- ============================================================
IF NOT EXISTS (SELECT * FROM sys.databases WHERE name = 'EduNovaDB')
    CREATE DATABASE EduNovaDB;
GO
USE EduNovaDB;
GO

-- ============================================================
-- 1. ENUM/DIMENSION TABLES
-- ============================================================

CREATE TABLE [AttendanceStatus](StatusId INT PRIMARY KEY, StatusName NVARCHAR(20));
INSERT INTO [AttendanceStatus] VALUES (1,'Present'),(2,'Absent'),(3,'Late'),(4,'Leave');

CREATE TABLE [ExamType](ExamTypeId INT PRIMARY KEY, TypeName NVARCHAR(20));
INSERT INTO [ExamType] VALUES (1,'Monthly'),(2,'HalfBook'),(3,'FullBook');

CREATE TABLE [PaymentMethod](PaymentMethodId INT PRIMARY KEY, MethodName NVARCHAR(30));
INSERT INTO [PaymentMethod] VALUES (1,'Cash'),(2,'BankTransfer'),(3,'Online');

CREATE TABLE [VoucherStatus](StatusId INT PRIMARY KEY, StatusName NVARCHAR(20));
INSERT INTO [VoucherStatus] VALUES (1,'Pending'),(2,'Paid'),(3,'Overdue'),(4,'Cancelled');

CREATE TABLE [SlotType](SlotTypeId INT PRIMARY KEY, TypeName NVARCHAR(20));
INSERT INTO [SlotType] VALUES (1,'Lecture'),(2,'Break'),(3,'Lunch'),(4,'Assembly');

CREATE TABLE [UserRole](RoleId INT PRIMARY KEY IDENTITY(1,1), RoleName NVARCHAR(50));
INSERT INTO [UserRole] (RoleName) VALUES ('Admin'),('Principal'),('Teacher'),('Accountant'),('Librarian');

CREATE TABLE [NotificationType](TypeId INT PRIMARY KEY IDENTITY(1,1), TypeName NVARCHAR(50));
INSERT INTO [NotificationType] (TypeName) VALUES ('Info'),('Warning'),('Alert'),('Substitution'),('FeeDue');

CREATE TABLE [SubstitutionStatus](StatusId INT PRIMARY KEY, StatusName NVARCHAR(20));
INSERT INTO [SubstitutionStatus] VALUES (1,'Pending'),(2,'Assigned'),(3,'Unassigned');

CREATE TABLE [BookStatus](StatusId INT PRIMARY KEY, StatusName NVARCHAR(20));
INSERT INTO [BookStatus] VALUES (1,'Available'),(2,'Issued'),(3,'Reserved'),(4,'Lost');

CREATE TABLE [LeaveStatus](StatusId INT PRIMARY KEY, StatusName NVARCHAR(20));
INSERT INTO [LeaveStatus] VALUES (1,'Pending'),(2,'Approved'),(3,'Rejected');

-- ============================================================
-- 2. MASTER DATA TABLES
-- ============================================================

CREATE TABLE [GradeClass](
    GradeClassId INT PRIMARY KEY IDENTITY(1,1),
    ClassName NVARCHAR(50) NOT NULL,
    Description NVARCHAR(200)
);

CREATE TABLE [Section](
    SectionId INT PRIMARY KEY IDENTITY(1,1),
    SectionName NVARCHAR(50) NOT NULL
);

CREATE TABLE [ClassSection](
    ClassSectionId INT PRIMARY KEY IDENTITY(1,1),
    GradeClassId INT REFERENCES [GradeClass](GradeClassId),
    SectionId INT REFERENCES [Section](SectionId),
    ClassTeacherId INT NULL,
    MaxStudents INT DEFAULT 40,
    IsActive BIT DEFAULT 1,
    DisplayName AS (SELECT g.ClassName + ' - ' + s.SectionName FROM GradeClass g, Section s WHERE g.GradeClassId=GradeClassId AND s.SectionId=SectionId)
);

CREATE TABLE [SubjectDomain](
    DomainId INT PRIMARY KEY IDENTITY(1,1),
    DomainName NVARCHAR(100) NOT NULL
);

CREATE TABLE [Subject](
    SubjectId INT PRIMARY KEY IDENTITY(1,1),
    SubjectName NVARCHAR(100) NOT NULL,
    SubjectCode NVARCHAR(20),
    DomainId INT REFERENCES [SubjectDomain](DomainId),
    IsActive BIT DEFAULT 1
);

CREATE TABLE [SchoolScheduleConfig](
    ConfigId INT PRIMARY KEY IDENTITY(1,1),
    EffectiveFrom DATE NOT NULL,
    SchoolStart TIME NOT NULL,
    SchoolEnd TIME NOT NULL,
    LectureDuration INT DEFAULT 40,
    BreakDuration INT DEFAULT 15,
    BreakAfterPeriod INT DEFAULT 3
);

CREATE TABLE [TimeSlot](
    TimeSlotId INT PRIMARY KEY IDENTITY(1,1),
    ConfigId INT REFERENCES [SchoolScheduleConfig](ConfigId),
    PeriodNo INT NOT NULL,
    StartTime TIME NOT NULL,
    EndTime TIME NOT NULL,
    SlotTypeId INT REFERENCES [SlotType](SlotTypeId)
);

-- ============================================================
-- 3. PERSON TABLES
-- ============================================================

CREATE TABLE [Person](
    PersonId INT PRIMARY KEY IDENTITY(1,1),
    FirstName NVARCHAR(50) NOT NULL,
    LastName NVARCHAR(50) NOT NULL,
    FullName AS (FirstName + ' ' + LastName),
    Phone NVARCHAR(20),
    Email NVARCHAR(100),
    Address NVARCHAR(200),
    DateOfBirth DATE,
    Gender INT, -- 1=Male, 2=Female, 3=Other
    CreatedAt DATETIME DEFAULT GETDATE(),
    CreatedBy NVARCHAR(50),
    UpdatedAt DATETIME,
    UpdatedBy NVARCHAR(50)
);

CREATE TABLE [StudentProfile](
    ProfileId INT PRIMARY KEY IDENTITY(1,1),
    StudentId INT NOT NULL,
    BloodGroup NVARCHAR(10),
    MedicalConditions NVARCHAR(200),
    PreviousSchool NVARCHAR(100),
    PhotoPath NVARCHAR(200)
);

CREATE TABLE [Guardian](
    GuardianId INT PRIMARY KEY IDENTITY(1,1),
    StudentId INT NOT NULL,
    Name NVARCHAR(100) NOT NULL,
    Relation NVARCHAR(50),
    Phone NVARCHAR(20),
    Occupation NVARCHAR(50),
    CNIC NVARCHAR(20)
);

CREATE TABLE [Student](
    StudentId INT PRIMARY KEY IDENTITY(1,1),
    PersonId INT REFERENCES [Person](PersonId),
    AdmissionNo NVARCHAR(30) UNIQUE NOT NULL,
    AdmissionDate DATE NOT NULL,
    IsActive BIT DEFAULT 1
);

CREATE TABLE [Teacher](
    TeacherId INT PRIMARY KEY IDENTITY(1,1),
    PersonId INT REFERENCES [Person](PersonId),
    EmployeeCode NVARCHAR(30) UNIQUE NOT NULL,
    Qualification NVARCHAR(100),
    JoiningDate DATE NOT NULL,
    Salary DECIMAL(18,2),
    IsActive BIT DEFAULT 1
);

CREATE TABLE [TeacherSubject](
    TeacherSubjectId INT PRIMARY KEY IDENTITY(1,1),
    TeacherId INT REFERENCES [Teacher](TeacherId),
    SubjectId INT REFERENCES [Subject](SubjectId)
);

CREATE TABLE [TeacherDomain](
    TeacherDomainId INT PRIMARY KEY IDENTITY(1,1),
    TeacherId INT REFERENCES [Teacher](TeacherId),
    DomainId INT REFERENCES [SubjectDomain](DomainId)
);

CREATE TABLE [Enrollment](
    EnrollmentId INT PRIMARY KEY IDENTITY(1,1),
    StudentId INT REFERENCES [Student](StudentId),
    ClassSectionId INT REFERENCES [ClassSection](ClassSectionId),
    EnrollmentDate DATE DEFAULT GETDATE(),
    AcademicYear NVARCHAR(10),
    IsActive BIT DEFAULT 1
);

-- ============================================================
-- 4. TIMETABLE & ATTENDANCE TABLES
-- ============================================================

CREATE TABLE [TimetableEntry](
    TimetableEntryId INT PRIMARY KEY IDENTITY(1,1),
    ClassSectionId INT REFERENCES [ClassSection](ClassSectionId),
    TimeSlotId INT REFERENCES [TimeSlot](TimeSlotId),
    SubjectId INT REFERENCES [Subject](SubjectId),
    TeacherId INT REFERENCES [Teacher](TeacherId),
    DayOfWeek INT NOT NULL,
    Room NVARCHAR(50)
);

CREATE TABLE [TeacherLeaveRequest](
    LeaveRequestId INT PRIMARY KEY IDENTITY(1,1),
    TeacherId INT REFERENCES [Teacher](TeacherId),
    LeaveDate DATE NOT NULL,
    Reason NVARCHAR(200),
    StatusId INT REFERENCES [LeaveStatus](StatusId) DEFAULT 1,
    RequestedAt DATETIME DEFAULT GETDATE()
);

CREATE TABLE [SubstitutionAssignment](
    SubstitutionId INT PRIMARY KEY IDENTITY(1,1),
    TimetableEntryId INT REFERENCES [TimetableEntry](TimetableEntryId),
    OriginalTeacherId INT REFERENCES [Teacher](TeacherId),
    SubstituteTeacherId INT NULL REFERENCES [Teacher](TeacherId),
    LeaveDate DATE NOT NULL,
    StatusId INT REFERENCES [SubstitutionStatus](StatusId) DEFAULT 1
);

CREATE TABLE [AttendanceRecord](
    AttendanceId INT PRIMARY KEY IDENTITY(1,1),
    StudentId INT REFERENCES [Student](StudentId),
    ClassSectionId INT REFERENCES [ClassSection](ClassSectionId),
    AttendanceDate DATE NOT NULL,
    StatusId INT REFERENCES [AttendanceStatus](StatusId),
    MarkedBy INT,
    MarkedAt DATETIME DEFAULT GETDATE()
);

-- ============================================================
-- 5. EXAM TABLES
-- ============================================================

CREATE TABLE [Exam](
    ExamId INT PRIMARY KEY IDENTITY(1,1),
    ExamName NVARCHAR(100) NOT NULL,
    ExamTypeId INT REFERENCES [ExamType](ExamTypeId),
    ClassSectionId INT REFERENCES [ClassSection](ClassSectionId),
    SubjectId INT REFERENCES [Subject](SubjectId),
    ExamDate DATE NOT NULL,
    TotalMarks INT NOT NULL,
    IsActive BIT DEFAULT 1
);

CREATE TABLE [Mark](
    MarksId INT PRIMARY KEY IDENTITY(1,1),
    ExamId INT REFERENCES [Exam](ExamId),
    StudentId INT REFERENCES [Student](StudentId),
    ObtainedMarks INT NOT NULL,
    Grade NVARCHAR(10)
);

-- ============================================================
-- 6. FEE TABLES
-- ============================================================

CREATE TABLE [FeeStructure](
    FeeStructureId INT PRIMARY KEY IDENTITY(1,1),
    ClassSectionId INT REFERENCES [ClassSection](ClassSectionId),
    MonthlyFee DECIMAL(18,2) NOT NULL,
    AdmissionFee DECIMAL(18,2) DEFAULT 0,
    MiscFee DECIMAL(18,2) DEFAULT 0
);

CREATE TABLE [FeeVoucher](
    VoucherId INT PRIMARY KEY IDENTITY(1,1),
    StudentId INT REFERENCES [Student](StudentId),
    ClassSectionId INT REFERENCES [ClassSection](ClassSectionId),
    Month NVARCHAR(20) NOT NULL,
    Year INT NOT NULL,
    TotalAmount DECIMAL(18,2) NOT NULL,
    DueDate DATE NOT NULL,
    StatusId INT REFERENCES [VoucherStatus](StatusId) DEFAULT 1
);

CREATE TABLE [FeePayment](
    PaymentId INT PRIMARY KEY IDENTITY(1,1),
    VoucherId INT REFERENCES [FeeVoucher](VoucherId),
    PaidAmount DECIMAL(18,2) NOT NULL,
    PaidOn DATETIME DEFAULT GETDATE(),
    PaymentMethodId INT REFERENCES [PaymentMethod](PaymentMethodId),
    ReceivedBy INT
);

-- ============================================================
-- 7. LIBRARY TABLES
-- ============================================================

CREATE TABLE [LibraryBook](
    BookId INT PRIMARY KEY IDENTITY(1,1),
    Title NVARCHAR(200) NOT NULL,
    ISBN NVARCHAR(20),
    Author NVARCHAR(100),
    Category NVARCHAR(50),
    TotalCopies INT DEFAULT 1,
    AvailableCopies INT DEFAULT 1,
    StatusId INT REFERENCES [BookStatus](StatusId) DEFAULT 1
);

CREATE TABLE [BookIssue](
    IssueId INT PRIMARY KEY IDENTITY(1,1),
    BookId INT REFERENCES [LibraryBook](BookId),
    StudentId INT REFERENCES [Student](StudentId),
    IssuedOn DATE DEFAULT GETDATE(),
    DueDate DATE NOT NULL,
    ReturnedOn DATE NULL,
    Fine DECIMAL(18,2) DEFAULT 0,
    IsReturned BIT DEFAULT 0
);

CREATE TABLE [LibraryFinePolicy](
    PolicyId INT PRIMARY KEY IDENTITY(1,1),
    FinePerDay DECIMAL(18,2) DEFAULT 10.00,
    GraceDays INT DEFAULT 2
);

-- ============================================================
-- 8. SECURITY & AUDIT TABLES
-- ============================================================

CREATE TABLE [AppUser](
    UserId INT PRIMARY KEY IDENTITY(1,1),
    Username NVARCHAR(50) UNIQUE NOT NULL,
    PasswordHash NVARCHAR(64) NOT NULL,
    DisplayName NVARCHAR(100),
    RoleId INT REFERENCES [UserRole](RoleId),
    IsActive BIT DEFAULT 1,
    CreatedAt DATETIME DEFAULT GETDATE(),
    CreatedBy NVARCHAR(50),
    UpdatedAt DATETIME,
    UpdatedBy NVARCHAR(50),
    LastLogin DATETIME
);

CREATE TABLE [RolePermission](
    RolePermissionId INT PRIMARY KEY IDENTITY(1,1),
    RoleId INT REFERENCES [UserRole](RoleId),
    PermissionCode NVARCHAR(50) NOT NULL
);

CREATE TABLE [AuditLog](
    LogId INT PRIMARY KEY IDENTITY(1,1),
    Timestamp DATETIME DEFAULT GETDATE(),
    Username NVARCHAR(50),
    Action NVARCHAR(50),
    Module NVARCHAR(50),
    Entity NVARCHAR(50),
    Details NVARCHAR(500)
);

CREATE TABLE [Notification](
    NotificationId INT PRIMARY KEY IDENTITY(1,1),
    Title NVARCHAR(200),
    Message NVARCHAR(500),
    NotificationTypeId INT REFERENCES [NotificationType](TypeId),
    TargetUserId INT NULL,
    IsRead BIT DEFAULT 0,
    CreatedAt DATETIME DEFAULT GETDATE()
);

-- Insert default admin user (password: admin123 hashed)
INSERT INTO [AppUser] (Username, PasswordHash, DisplayName, RoleId, IsActive)
VALUES ('admin', '240BE518FABD2724DDB6F04EEB1DA5967448D7E831C08C8FA822809F74C720A9', 'Administrator', 1, 1);

GO
